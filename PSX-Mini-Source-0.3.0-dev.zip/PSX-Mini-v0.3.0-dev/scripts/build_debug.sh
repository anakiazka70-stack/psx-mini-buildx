#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.14.8 is required. Install it or build from Android Studio." >&2
  exit 1
fi
exec gradle :app:assembleDebug "$@"
