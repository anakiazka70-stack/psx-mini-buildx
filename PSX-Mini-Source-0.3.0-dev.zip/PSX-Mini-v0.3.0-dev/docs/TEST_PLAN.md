# Test plan — PSX Mini 0.3.0-dev

## Automated checks

- [x] CUE validator test source covers valid tracks, missing tracks, no FILE entries, Windows-style separators, path flattening after import, and filename-case normalization.
- [x] Standalone Kotlin smoke test for CUE path flattening and actual on-disk filename case passed; Gradle/JUnit execution remains pending with the Android build.
- [x] Host fake-core test validates Libretro core loading, API negotiation, game loading, video frame delivery, audio buffering, joypad input, unload and shutdown.
- [x] Host JNI smoke test validates Java-to-native bridge loading and core-probe error handling.
- [x] Core verifier test accepts a complete host core and rejects missing exports and a mismatched ABI.
- [x] 16 KB alignment configuration test verifies frontend linker flags and applies the pinned-core patch to a representative upstream Android.mk fixture.
- [x] APK packaging verifier test checks required native entries and exercises the Android `zipalign -P 16` command path with a host stub.
- [x] ELF alignment verifier tests exercise compliant and non-compliant `PT_LOAD` and `GNU_RELRO` examples using a readelf output fixture.
- [ ] Core verifier passes against the actual Android ARM64 PCSX ReARMed binary.
- [x] Shell scripts pass `bash -n` syntax validation.
- [ ] GitHub Actions workflow has been run successfully (requires publishing the source to a GitHub repository).
- [ ] Android NDK/CMake build succeeds for `arm64-v8a`.
- [ ] APK verifier confirms both native libraries are present in the final APK.
- [ ] Android Gradle build succeeds and APK artifact is produced.

## Android build and app shell

- [ ] Gradle sync succeeds with the configured AGP / Gradle / Kotlin / JDK toolchain.
- [ ] Debug APK builds and installs.
- [ ] App opens without crashing.
- [ ] Device page displays Android version and supported ABIs.
- [ ] Native bridge displays `JNI BRIDGE READY` and the device ABI.
- [ ] Packaged PCSX ReARMed library initializes through the native frontend.

## Android file picker and library

- [ ] Add Game Files opens the Android document picker.
- [ ] Cancel returns to the app without a crash.
- [ ] One CHD/PBP/ISO image can be selected and copied.
- [ ] A CUE plus all referenced BIN tracks can be selected together.
- [ ] Missing track names are reported for incomplete selections.
- [ ] No broad storage permission prompt is shown.
- [ ] Imported files remain listed after closing and reopening the app.
- [ ] Play action opens the landscape player screen for an imported image.

## Player runtime

- [ ] Player screen displays software video from the real PCSX ReARMed core.
- [ ] Audio plays without sustained crackling or major desynchronization.
- [ ] Touch controls register all digital joypad directions and buttons.
- [ ] Stop/back reliably unloads the game and deinitializes the core.
- [ ] Test Pepsi Man from the supplied CUE/BIN set with HLE BIOS.
- [ ] Repeat with a user-provided compatible BIOS file, if available.

## Optional BIOS

- [ ] BIOS import picker opens.
- [ ] Candidate file is copied into app-private `files/system/` storage.
- [ ] Core detects a compatible user-provided BIOS where applicable.

## Target device

- [ ] Repeat all tests on Infinix HOT 70 / XOS.
- [ ] Verify performance, thermal behavior, frame pacing and memory use on the target device.
