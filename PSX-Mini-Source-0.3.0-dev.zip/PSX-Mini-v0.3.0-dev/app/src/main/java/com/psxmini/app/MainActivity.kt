package com.psxmini.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.psxmini.app.data.CueValidator
import com.psxmini.app.data.GameRepository
import com.psxmini.app.emulator.EmulatorController
import com.psxmini.app.emulator.NativeBridge
import com.psxmini.app.platform.DeviceInfo
import com.psxmini.app.player.PlayerActivity
import com.psxmini.app.storage.ContentStager
import com.psxmini.app.storage.SafDocumentPicker
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val pickGameRequest = 2101
    private val pickBiosRequest = 2102
    private val ioExecutor = Executors.newSingleThreadExecutor()

    private lateinit var statusText: TextView
    private lateinit var libraryContainer: LinearLayout
    private lateinit var libraryCount: TextView

    private val stager by lazy { ContentStager(this) }
    private val repository by lazy { GameRepository(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshLibrary()
    }

    override fun onDestroy() {
        ioExecutor.shutdown()
        super.onDestroy()
    }

    @Deprecated("Uses the platform document picker callback for the no-dependency starter build")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return

        val selected = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (index in 0 until clip.itemCount) selected += clip.getItemAt(index).uri
        }
        if (selected.isEmpty()) data.data?.let(selected::add)
        if (selected.isEmpty()) {
            showStatus("No file was selected.", isError = true)
            return
        }

        when (requestCode) {
            pickGameRequest -> importGames(selected)
            pickBiosRequest -> importBios(selected.first())
        }
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
            setBackgroundColor(Color.rgb(10, 16, 32))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(page)
        }
        setContentView(scroll)

        page.addView(text("PSX MINI", 30, Color.WHITE, bold = true))
        page.addView(text("PLAYSTATION 1 FRONTEND · ANDROID", 11, Color.rgb(130, 164, 220), bold = true).apply {
            letterSpacing = 0.10f
            setPadding(0, dp(4), 0, dp(18))
        })

        val hero = card()
        hero.addView(text("Your PS1 library,\nyour way.", 23, Color.WHITE, bold = true))
        hero.addView(text(
            "Import your own PS1 disc images and launch them through the native Libretro frontend when the PCSX ReARMed core is packaged in this build.",
            13, Color.rgb(190, 201, 222)
        ).apply { setPadding(0, dp(10), 0, 0) })
        page.addView(hero, matchWrap())

        page.addView(sectionTitle("LIBRARY"))
        page.addView(actionButton("＋  Add game files", primary = true) {
            try {
                startActivityForResult(SafDocumentPicker.gameFiles(), pickGameRequest)
            } catch (error: Exception) {
                showStatus("Android file picker could not be opened: ${error.message}", isError = true)
            }
        })
        page.addView(actionButton("Optional: Import BIOS file", primary = false) {
            try {
                startActivityForResult(SafDocumentPicker.biosFile(), pickBiosRequest)
            } catch (error: Exception) {
                showStatus("Android file picker could not be opened: ${error.message}", isError = true)
            }
        }.apply { setPadding(0, dp(5), 0, dp(5)) })

        statusText = text("Ready. No files imported yet.", 12, Color.rgb(177, 192, 216))
        statusText.setPadding(dp(2), dp(10), dp(2), dp(10))
        page.addView(statusText)

        libraryCount = text("0 imported", 12, Color.rgb(137, 158, 190), bold = true)
        page.addView(libraryCount)
        libraryContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(libraryContainer, matchWrap())

        page.addView(sectionTitle("NATIVE BRIDGE"))
        val nativeCard = card()
        nativeCard.addView(text(
            if (NativeBridge.isLoaded) "JNI BRIDGE READY" else "JNI BRIDGE UNAVAILABLE",
            13,
            if (NativeBridge.isLoaded) Color.rgb(115, 211, 167) else Color.rgb(255, 150, 150),
            bold = true
        ))
        nativeCard.addView(text(NativeBridge.buildInfoOrMessage(), 12, Color.rgb(190, 201, 222))
            .apply { setPadding(0, dp(7), 0, 0) })
        page.addView(nativeCard, matchWrap())

        page.addView(sectionTitle("EMULATOR STATUS"))
        val emulatorCard = card()
        val coreStateText = text("CHECKING CORE…", 13, Color.rgb(255, 204, 121), bold = true)
        val coreDetailText = text(
            "Checking whether the PCSX ReARMed binary is packaged in this build…",
            12, Color.rgb(190, 201, 222)
        ).apply { setPadding(0, dp(7), 0, 0) }
        emulatorCard.addView(coreStateText)
        emulatorCard.addView(coreDetailText)
        page.addView(emulatorCard, matchWrap())
        // This is only a file-presence check. The actual core initialization happens
        // in the player thread when the user presses Play, avoiding a startup race.
        val controller = EmulatorController(File(applicationInfo.nativeLibraryDir))
        val coreProbe = controller.probePackagedCore()
        val coreAvailable = coreProbe.startsWith("CORE_FILE_FOUND")
        coreStateText.text = if (coreAvailable) "PCSX REARMED BINARY FOUND" else "PCSX REARMED CORE NOT READY"
        coreStateText.setTextColor(
            if (coreAvailable) Color.rgb(115, 211, 167) else Color.rgb(255, 204, 121)
        )
        coreDetailText.text = coreProbe + "\n\n" + controller.gameplayStatus()

        page.addView(sectionTitle("DEVICE"))
        val deviceCard = card()
        deviceCard.addView(text(DeviceInfo.androidVersion(), 13, Color.WHITE, bold = true))
        deviceCard.addView(text("Supported ABI: ${DeviceInfo.supportedAbis()}", 12, Color.rgb(190, 201, 222))
            .apply { setPadding(0, dp(7), 0, 0) })
        page.addView(deviceCard, matchWrap())

        page.addView(text(
            "BIOS and game files are not included. Import only files you are entitled to use. Imported copies are stored inside PSX Mini's private app storage.",
            11, Color.rgb(116, 133, 160)
        ).apply { setPadding(dp(2), dp(20), dp(2), 0) })
    }

    private fun importGames(uris: List<Uri>) {
        showStatus("Importing ${uris.size} selected file(s)…")
        ioExecutor.execute {
            try {
                val result = stager.importGameUris(uris)
                val cueFiles = result.copiedFiles.filter { it.extension.equals("cue", true) }
                val missing = cueFiles.flatMap { CueValidator.missingTracks(it) }.distinct()
                val message = buildString {
                    append("Imported ${result.copiedFiles.size} file(s).")
                    if (missing.isNotEmpty()) append(" Missing CUE track(s): ${missing.joinToString()}. Select the CUE and all referenced track files together.")
                    if (result.skippedFiles.isNotEmpty()) append(" Skipped: ${result.skippedFiles.joinToString()}")
                    append(" Select Play after a compatible PCSX ReARMed core is packaged in the APK.")
                }
                runOnUiThread {
                    showStatus(message, isError = missing.isNotEmpty() || result.copiedFiles.isEmpty())
                    refreshLibrary()
                }
            } catch (error: Exception) {
                runOnUiThread { showStatus("Import failed: ${error.message ?: "unknown error"}", isError = true) }
            }
        }
    }

    private fun importBios(uri: Uri) {
        showStatus("Importing BIOS file…")
        ioExecutor.execute {
            try {
                val file = stager.importBiosUri(uri)
                runOnUiThread { showStatus("BIOS file copied to private storage: ${file.name}. The file has not yet been validated by a running emulator core.") }
            } catch (error: Exception) {
                runOnUiThread { showStatus("BIOS import failed: ${error.message ?: "unknown error"}", isError = true) }
            }
        }
    }

    private fun refreshLibrary() {
        if (!::libraryContainer.isInitialized) return
        libraryContainer.removeAllViews()
        val games = repository.listGames()
        libraryCount.text = "${games.size} imported game folder(s)"
        if (games.isEmpty()) {
            libraryContainer.addView(card().apply {
                addView(text("Your library is empty", 14, Color.WHITE, bold = true))
                addView(text("Tap Add game files and select a CHD/PBP/ISO image, or select a CUE together with every BIN track it references.",
                    12, Color.rgb(177, 192, 216)).apply { setPadding(0, dp(6), 0, 0) })
            }, matchWrap())
            return
        }

        games.forEach { game ->
            val row = card()
            row.addView(text(game.displayName, 15, Color.WHITE, bold = true))
            row.addView(text("${game.format} · ${formatBytes(game.folderSize())}", 11, Color.rgb(137, 158, 190))
                .apply { setPadding(0, dp(5), 0, 0) })
            val status = when {
                game.format == "CUE" && !game.cueComplete -> "CUE incomplete — one or more track files are missing"
                game.format == "BIN" && !game.cueComplete -> "BIN image needs its matching CUE sheet before PCSX ReARMed can load it"
                else -> "Imported · select Play to launch the PS1 core"
            }
            row.addView(text(status, 11, if (game.cueComplete) Color.rgb(115, 211, 167) else Color.rgb(255, 190, 110))
                .apply { setPadding(0, dp(6), 0, 0) })
            if (game.cueComplete) {
                row.addView(actionButton("▶  Play game", primary = true) {
                    startActivity(Intent(this, PlayerActivity::class.java).putExtra(
                        PlayerActivity.EXTRA_GAME_PATH, game.mainFile.absolutePath
                    ))
                }.apply { setPadding(dp(10), dp(10), dp(10), dp(10)) })
            } else {
                row.addView(text(
                    if (game.format == "BIN") "Import a matching CUE sheet together with every BIN track before starting this game."
                    else "Fix the missing CUE tracks before starting this game.",
                    11, Color.rgb(255, 190, 110))
                    .apply { setPadding(0, dp(7), 0, 0) })
            }
            libraryContainer.addView(row, matchWrap())
        }
    }

    private fun File.folderSize(): Long = walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun showStatus(message: String, isError: Boolean = false) {
        if (!::statusText.isInitialized) return
        statusText.text = message
        statusText.setTextColor(if (isError) Color.rgb(255, 150, 150) else Color.rgb(177, 192, 216))
    }

    private fun sectionTitle(value: String) = text(value, 11, Color.rgb(130, 164, 220), bold = true).apply {
        setPadding(dp(2), dp(22), 0, dp(9))
        letterSpacing = 0.09f
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        background = rounded(Color.rgb(20, 30, 51), dp(16))
    }

    private fun actionButton(label: String, primary: Boolean, action: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setTextColor(if (primary) Color.rgb(8, 18, 37) else Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(if (primary) Color.rgb(120, 169, 255) else Color.rgb(35, 49, 75), dp(13))
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }.also { /* Layout margin is applied by the parent below. */ }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setLineSpacing(dp(2).toFloat(), 1f)
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(9) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private fun formatBytes(bytes: Long): String = when {
            bytes >= 1024L * 1024L * 1024L -> "%.2f GB".format(bytes / (1024.0 * 1024.0 * 1024.0))
            bytes >= 1024L * 1024L -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
            bytes >= 1024L -> "%.1f KB".format(bytes / 1024.0)
            else -> "$bytes B"
        }
    }
}
