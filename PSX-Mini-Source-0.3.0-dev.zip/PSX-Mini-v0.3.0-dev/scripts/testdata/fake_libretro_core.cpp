#include <cstdint>

struct RetroSystemInfoProbe {
    const char* library_name;
    const char* library_version;
    const char* valid_extensions;
    bool need_fullpath;
    bool block_extract;
};

extern "C" __attribute__((visibility("default"))) unsigned int retro_api_version() {
    return 1;
}

extern "C" __attribute__((visibility("default"))) void retro_get_system_info(RetroSystemInfoProbe* info) {
    if (info == nullptr) return;
    info->library_name = "PSX Mini Libretro Probe Test Stub";
    info->library_version = "test-1";
    info->valid_extensions = "cue|bin|chd";
    info->need_fullpath = true;
    info->block_extract = false;
}
