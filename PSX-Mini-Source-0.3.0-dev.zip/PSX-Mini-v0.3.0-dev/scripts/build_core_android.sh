#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOCK_FILE="$ROOT/core/pcsx-rearmed/UPSTREAM.lock"
CORE_REPO="$(sed -n 's/^repository=//p' "$LOCK_FILE" | head -n1)"
CORE_COMMIT="$(sed -n 's/^commit=//p' "$LOCK_FILE" | head -n1)"
ABI="${PSX_CORE_ABI:-arm64-v8a}"

if [[ -z "${CORE_REPO}" || -z "${CORE_COMMIT}" ]]; then
  echo "Missing repository or commit pin in $LOCK_FILE" >&2
  exit 2
fi
if [[ ! "$CORE_COMMIT" =~ ^[0-9a-f]{40}$ ]]; then
  echo "Core commit must be a full 40-character SHA: $CORE_COMMIT" >&2
  exit 2
fi

NDK_DIR="${ANDROID_NDK_HOME:-}"
if [[ -z "$NDK_DIR" && -n "${ANDROID_HOME:-}" ]]; then
  NDK_DIR="$ANDROID_HOME/ndk/27.2.12479018"
fi
if [[ -z "$NDK_DIR" || ! -x "$NDK_DIR/ndk-build" ]]; then
  echo "Android NDK 27.2.12479018 was not found. Set ANDROID_NDK_HOME." >&2
  exit 2
fi

WORK_DIR="${PSX_CORE_WORK_DIR:-$ROOT/.build/pcsx-rearmed}"
mkdir -p "$(dirname "$WORK_DIR")"
if [[ ! -d "$WORK_DIR/.git" ]]; then
  rm -rf "$WORK_DIR"
  git clone --filter=blob:none "$CORE_REPO" "$WORK_DIR"
fi

git -C "$WORK_DIR" fetch --depth 1 origin "$CORE_COMMIT"
git -C "$WORK_DIR" checkout --detach "$CORE_COMMIT"
git -C "$WORK_DIR" submodule sync --recursive
git -C "$WORK_DIR" submodule update --init --recursive

# Upstream sets max-page-size=16384. NDK r27 also needs common-page-size=16384
# for 16 KB device compatibility; apply and preserve this small local GPL patch.
if ! grep -q -- '-Wl,-z,common-page-size=16384' "$WORK_DIR/jni/Android.mk"; then
  git -C "$WORK_DIR" apply --check "$ROOT/patches/pcsx-rearmed-16kb-page-alignment.patch"
  git -C "$WORK_DIR" apply "$ROOT/patches/pcsx-rearmed-16kb-page-alignment.patch"
fi

# Upstream provides its own Android NDK build files in jni/Android.mk and
# jni/Application.mk. Use that Android-specific path rather than a guessed
# generic-Unix cross-compile configuration.
"$NDK_DIR/ndk-build" -C "$WORK_DIR/jni" \
  APP_ABI="$ABI" \
  APP_PLATFORM=android-24 \
  APP_STL=c++_static \
  NDK_OUT="$WORK_DIR/obj" \
  NDK_LIBS_OUT="$WORK_DIR/libs"

BUILT_CORE="$WORK_DIR/libs/$ABI/libretro.so"
if [[ ! -s "$BUILT_CORE" ]]; then
  echo "Expected upstream core output was not produced: $BUILT_CORE" >&2
  exit 1
fi
"$ROOT/scripts/verify_core_binary.sh" "$BUILT_CORE" "$ABI" "$NDK_DIR"

DEST_DIR="$ROOT/app/src/main/jniLibs/$ABI"
mkdir -p "$DEST_DIR"
install -m 0644 "$BUILT_CORE" "$DEST_DIR/libpcsx_rearmed_libretro.so"
mkdir -p "$ROOT/app/src/main/assets/licenses"
install -m 0644 "$WORK_DIR/COPYING" "$ROOT/app/src/main/assets/licenses/PCSX-ReARMed-COPYING"
cat > "$ROOT/app/src/main/assets/pcsx-rearmed-build.txt" <<BUILDINFO
PCSX ReARMed upstream core
Repository: $CORE_REPO
Commit: $CORE_COMMIT
ABI: $ABI
License: GPL-2.0
Build method: upstream jni/Android.mk using Android NDK 27.2.12479018
BUILDINFO

# Keep the exact corresponding upstream source alongside the APK build output
# for GPL source availability and reproducibility.
SOURCE_ARCHIVE="${PSX_CORE_SOURCE_ARCHIVE:-$ROOT/PSX-ReARMed-$CORE_COMMIT-source.tar.gz}"
tar -czf "$SOURCE_ARCHIVE" \
  --exclude=.git \
  --exclude='obj' \
  --exclude='libs' \
  -C "$WORK_DIR" .

echo "Built and staged $DEST_DIR/libpcsx_rearmed_libretro.so"
echo "Upstream commit: $CORE_COMMIT"
echo "Corresponding source archive: $SOURCE_ARCHIVE"
echo "Note: the frontend runtime is implemented, but real-core boot and device gameplay are not verified until tested."
