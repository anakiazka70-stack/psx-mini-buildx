# PSX Mini — Android PS1 frontend project

**Current source version:** `0.3.0-dev`

PSX Mini is a native Android frontend for a PlayStation 1 Libretro core. This milestone hardens core packaging for the target `arm64-v8a` device and adds checks for the real core binary and final APK. The Libretro runtime lifecycle and software callback path remain the implemented frontend. It has been tested against a purpose-built fake Libretro shared library on the host. Actual PCSX ReARMed gameplay and device output remain unverified until the Android NDK build and device test are run.

## Current features

- Kotlin + Android View UI and a landscape player screen.
- Android Storage Access Framework file picker; no broad storage permission.
- Copies selected game images and optional user-provided BIOS files into app-private storage.
- Normalizes directory-qualified CUE track references after staging, matches track filenames case-insensitively and rewrites them to their exact on-disk spelling, checks for missing tracks, and blocks bare BIN playback until a matching CUE is imported.
- C++17 JNI frontend with dynamic Libretro core loading and API version/export checks.
- Environment, software-video, audio, input-poll and joypad input callbacks.
- Core system/save directories and legacy core-options defaults.
- Full-path and in-memory game loading modes.
- `retro_run()` frame execution, native audio queue, and RGB565 Android Surface output.
- Touch controls mapped to Libretro joypad IDs; the player keeps the screen awake during gameplay.
- Host fake-core tests for lifecycle, video, audio, input and JNI loading.
- Core-binary verification for ELF architecture and required Libretro exports.
- APK verification that the frontend and matching ARM64 PCSX ReARMed binary are both packaged.
- Initial APK ABI filter aligned to the only bundled core ABI: `arm64-v8a`.
- Both native libraries are linked with 16 KB ELF segment alignment flags; the core makefile receives a small reproducible local patch for NDK r27.
- PCSX ReARMed source revision pinned in `core/pcsx-rearmed/UPSTREAM.lock`.
- GitHub Actions workflow builds a debug APK and uploads matching frontend and PCSX ReARMed source archives.

## Important status distinction

The native frontend runtime is implemented and tested against a fake core. That proves the frontend callback and transport layer, not the behavior of the real PCSX ReARMed core. The actual upstream core build and Android NDK APK build have not yet been executed in this workspace. The GitHub Actions workflow now verifies the core ABI/exports and checks that the APK contains both native libraries. Rendering/audio on an Android device and Pepsi Man compatibility remain unverified.

## Toolchain

- Android Gradle Plugin 8.13.2
- Gradle 8.14.8
- Kotlin Gradle Plugin 2.3.21
- JDK 17
- Compile SDK 36 / target SDK 35 / min SDK 24
- Android NDK 27.2.12479018
- CMake 3.22.1

## Build

Recommended from a phone: push this source folder to a GitHub repository and run **Actions → Android APK → Run workflow**. Download the `PSX-Mini-debug-build-bundle` artifact. It contains `app-debug.apk`, the PSX Mini frontend source archive, and the matching PCSX ReARMed GPL source archive.

Local build commands:

```bash
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/27.2.12479018"
./scripts/build_core_android.sh
./scripts/test_libretro_frontend_host.sh
./scripts/test_native_bridge_host.sh
./scripts/test_core_binary_verifier.sh
./scripts/test_android_native_syntax.sh
./scripts/test_16kb_alignment_config.sh
./scripts/test_verify_apk.sh
./scripts/test_elf_alignment_verifier.sh
gradle :app:testDebugUnitTest :app:assembleDebug
./scripts/verify_apk.sh app/build/outputs/apk/debug/app-debug.apk arm64-v8a "$ANDROID_NDK_HOME"
./scripts/archive_project_source.sh
```

See `docs/BUILD_ANDROID.md`, `docs/CORE_INTEGRATION.md`, `docs/FRONTEND_RUNTIME.md`, `LICENSES.md`, and `THIRD_PARTY_NOTICES.md` for details.

## Legal notes

PCSX ReARMed is GPL-2.0. The corresponding source revision and license must accompany distributed builds containing the core. No BIOS, game image, PlayStation firmware, Sony assets, or copyrighted cover art is included. Users import content they are entitled to use.
