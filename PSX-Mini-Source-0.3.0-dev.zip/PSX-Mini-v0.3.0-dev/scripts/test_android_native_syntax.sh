#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JAVAC_BIN="$(command -v javac || true)"
if [[ -z "$JAVAC_BIN" ]]; then
  echo "ANDROID_NATIVE_SYNTAX_SKIP: javac/JDK headers are unavailable." >&2
  exit 2
fi
JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$JAVAC_BIN")")")"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT
mkdir -p "$TEMP_DIR/stubs/android"

cat > "$TEMP_DIR/stubs/android/native_window.h" <<'H'
#pragma once
#include <stdint.h>
struct ANativeWindow {};
struct ANativeWindow_Buffer {
    int32_t width;
    int32_t height;
    int32_t stride;
    int32_t format;
    void *bits;
};
#define WINDOW_FORMAT_RGB_565 4
int ANativeWindow_lock(ANativeWindow *, ANativeWindow_Buffer *, void *);
int ANativeWindow_unlockAndPost(ANativeWindow *);
void ANativeWindow_release(ANativeWindow *);
int ANativeWindow_setBuffersGeometry(ANativeWindow *, int32_t, int32_t, int32_t);
H
cat > "$TEMP_DIR/stubs/android/native_window_jni.h" <<'H'
#pragma once
#include <jni.h>
#include <android/native_window.h>
ANativeWindow *ANativeWindow_fromSurface(JNIEnv *, jobject);
H
cat > "$TEMP_DIR/stubs/android/log.h" <<'H'
#pragma once
#define ANDROID_LOG_INFO 4
H

for source in \
  "$ROOT/app/src/main/cpp/jni/native_bridge.cpp" \
  "$ROOT/app/src/main/cpp/jni/libretro_frontend.cpp"; do
  c++ -std=c++17 -Wall -Wextra -Wpedantic -D__ANDROID__ -D__ANDROID_API__=24 \
    -I"$TEMP_DIR/stubs" \
    -I"$ROOT/app/src/main/cpp/include" \
    -I"$JAVA_HOME/include" -I"$JAVA_HOME/include/linux" \
    -fsyntax-only "$source"
done

echo "Android native branch syntax check (host stubs): PASS"
