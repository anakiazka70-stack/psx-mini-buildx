#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 2 || $# -gt 3 ]]; then
  echo "Usage: $0 <core-shared-library> <expected-abi> [android-ndk-root]" >&2
  exit 2
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE_PATH="$1"
EXPECTED_ABI="$2"
NDK_ROOT="${3:-${ANDROID_NDK_HOME:-}}"

if [[ ! -s "$CORE_PATH" ]]; then
  echo "CORE_VERIFY_FAILED: file does not exist or is empty: $CORE_PATH" >&2
  exit 1
fi

"$ROOT/scripts/verify_elf.sh" "$CORE_PATH" "$EXPECTED_ABI" "$NDK_ROOT"

READELF=""
if [[ -n "$NDK_ROOT" ]]; then
  HOST_TAG=""
  case "$(uname -s)-$(uname -m)" in
    Linux-x86_64) HOST_TAG="linux-x86_64" ;;
    Darwin-arm64|Darwin-x86_64) HOST_TAG="darwin-x86_64" ;;
  esac
  CANDIDATE="$NDK_ROOT/toolchains/llvm/prebuilt/$HOST_TAG/bin/llvm-readelf"
  if [[ -n "$HOST_TAG" && -x "$CANDIDATE" ]]; then READELF="$CANDIDATE"; fi
fi
if [[ -z "$READELF" ]]; then READELF="$(command -v llvm-readelf || command -v readelf || true)"; fi
if [[ -z "$READELF" ]]; then
  echo "CORE_VERIFY_FAILED: llvm-readelf or readelf is required." >&2
  exit 2
fi
SYMBOLS="$($READELF --dyn-syms --wide "$CORE_PATH")"
REQUIRED_SYMBOLS=(
  retro_api_version
  retro_set_environment
  retro_set_video_refresh
  retro_set_audio_sample
  retro_set_audio_sample_batch
  retro_set_input_poll
  retro_set_input_state
  retro_init
  retro_deinit
  retro_get_system_info
  retro_get_system_av_info
  retro_load_game
  retro_unload_game
  retro_run
)
for symbol in "${REQUIRED_SYMBOLS[@]}"; do
  if ! printf '%s\n' "$SYMBOLS" | grep -Eq "[[:space:]]${symbol}(@[^[:space:]]*)?$"; then
    echo "CORE_VERIFY_FAILED: missing exported Libretro symbol '$symbol'." >&2
    exit 1
  fi
done

echo "CORE_VERIFY_OK: $CORE_PATH"
echo "ABI: $EXPECTED_ABI verified"
echo "Required Libretro exports: ${#REQUIRED_SYMBOLS[@]} present"
