#include "libretro_frontend.h"
#include "libretro_api_subset.h"

#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <dlfcn.h>

int main(int argc, char **argv) {
    assert(argc == 3);
    const char *corePath = argv[1];
    const char *gamePath = argv[2];

    const char *coreStatus = psxmini_load_core(corePath, "/tmp/psxmini-system", "/tmp/psxmini-saves");
    assert(coreStatus != nullptr);
    assert(std::string(coreStatus).find("CORE_READY") == 0);
    assert(std::string(coreStatus).find("PSX Mini Test Game Core") != std::string::npos);
    assert(psxmini_is_core_loaded());
    void *coreHandle = dlopen(corePath, RTLD_NOW | RTLD_LOCAL);
    assert(coreHandle != nullptr);
    using GetUnsigned = unsigned (*)();
    auto selectedPort = reinterpret_cast<GetUnsigned>(dlsym(coreHandle, "fake_selected_port"));
    auto selectedDevice = reinterpret_cast<GetUnsigned>(dlsym(coreHandle, "fake_selected_device"));
    assert(selectedPort && selectedDevice);
    assert(selectedPort() == 0);
    assert(selectedDevice() == RETRO_DEVICE_JOYPAD);
    dlclose(coreHandle);

    const char *gameStatus = psxmini_load_game(gamePath);
    assert(gameStatus != nullptr);
    assert(std::string(gameStatus).find("GAME_LOADED") == 0);
    assert(psxmini_is_game_loaded());
    assert(psxmini_get_frame_rate() == 60.0);

    psxmini_set_input_mask(static_cast<uint16_t>(1U << RETRO_DEVICE_ID_JOYPAD_UP));
    psxmini_run_frame();

    PsxMiniVideoInfo info{};
    assert(psxmini_get_video_info(&info) == 1);
    assert(info.width == 2 && info.height == 2);
    assert(info.pitch == 4 && info.pixel_format == RETRO_PIXEL_FORMAT_RGB565);
    assert(info.data_size == 8);

    std::vector<uint8_t> frame(info.data_size);
    assert(psxmini_copy_video_frame(frame.data(), frame.size()) == frame.size());
    uint16_t firstPixel = 0;
    std::memcpy(&firstPixel, frame.data(), sizeof(firstPixel));
    assert(firstPixel == 0xFFFF); // Fake core encodes the UP button into the first pixel.

    int16_t audio[8]{};
    const size_t samples = psxmini_pull_audio(audio, 8);
    assert(samples == 4);
    assert(audio[0] == 100 && audio[1] == -100 && audio[2] == 200 && audio[3] == -200);

    psxmini_unload_game();
    assert(!psxmini_is_game_loaded());
    psxmini_shutdown();
    assert(!psxmini_is_core_loaded());
    std::puts("Libretro frontend host smoke test: PASS");
    return 0;
}
