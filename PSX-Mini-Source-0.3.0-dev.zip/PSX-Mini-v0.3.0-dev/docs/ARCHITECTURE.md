# Architecture — v0.3.0-dev

```text
MainActivity (Android Views)
  |-- GameRepository / ContentStager / SAF picker
  |-- EmulatorController (packaged-core file check)
  `-- PlayerActivity (landscape)
        |-- SurfaceView -> Android Surface
        |-- AudioTrack <- native PCM batch queue
        |-- touch buttons -> joypad bitmask
        `-- emulation worker thread
                |
             NativeBridge.kt (JNI)
                |
          libpsxmini_native.so
                |-- JNI / ANativeWindow presenter
                `-- LibretroFrontend (C++17)
                      |-- dlopen / required retro_* exports
                      |-- environment callback + core option defaults
                      |-- video/audio/input callbacks
                      |-- retro_load_game / retro_run / unload
                      `-- libpcsx_rearmed_libretro.so (packaged separately)
```

The Libretro core is a dynamically loaded shared library built from the pinned PCSX ReARMed source. The v0.3.0-dev packaging workflow is intentionally limited to arm64-v8a and verifies ELF architecture and required Libretro exports before the APK is assembled. The PSX Mini JNI frontend owns the Libretro lifecycle and callbacks, and selects the standard digital joypad for player 1 when the core exposes the controller-port function. The initial video path is software framebuffer -> reusable native frame buffer -> RGB565 Surface buffer, with pitch/size validation; it does not request a hardware-rendering context. Audio is queued as interleaved signed 16-bit stereo samples and drained into Android `AudioTrack`. A single background worker owns core load, game load, frame execution, unload, and deinitialization.

Automated host tests use a purpose-built fake core. They validate the frontend ABI path, not the real emulator core. Actual Android NDK core build, APK assembly, and device-level gameplay remain pending.
