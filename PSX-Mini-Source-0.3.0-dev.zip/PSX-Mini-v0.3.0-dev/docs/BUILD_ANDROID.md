# Android build instructions

## Requirements

- Android SDK Platform 36 and Build Tools 36.0.0.
- JDK 17.
- Gradle 8.14.8.
- Android NDK 27.2.12479018.
- CMake 3.22.1.
- Internet access to fetch the pinned PCSX ReARMed source and Android Gradle dependencies.

## Build with GitHub Actions (recommended when building from a phone)

The workflow builds the PCSX ReARMed core from the exact commit recorded in `core/pcsx-rearmed/UPSTREAM.lock`, using its upstream Android NDK project under `jni/`. It packages the `arm64-v8a` core into the APK, then verifies the core ELF architecture and required Libretro exports, verifies that the APK contains the ARM64 frontend and PCSX ReARMed core, and uploads one artifact containing the debug APK, the PSX Mini frontend source archive, and the corresponding PCSX ReARMed GPL source archive.

After putting the project in a GitHub repository:

1. Open **Actions → Android APK → Run workflow**.
2. Open the completed run.
3. Download `PSX-Mini-debug-build-bundle`.
4. Extract `app-debug.apk` and install it on an arm64 Android device.
5. Keep `PSX-Mini-frontend-source.tar.gz` and `PSX-ReARMed-source.tar.gz` with the APK. The first contains the matching frontend source; the second contains the exact pinned GPL core source.

The native frontend and core are built with 16 KB ELF segment alignment flags. Shared libraries use the modern uncompressed packaging mode, and the APK verifier runs `zipalign -c -P 16 4` in addition to checking each ELF segment. The core build applies the documented local patch in `patches/pcsx-rearmed-16kb-page-alignment.patch`; the generated matching core source archive includes this change.

The first build downloads the Android SDK/NDK packages, core source, and Gradle dependencies. The workflow may fail if upstream source or NDK dependencies change or are unavailable; the exact core commit is pinned to limit drift.

## Build locally

First build and stage the upstream core:

```bash
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/27.2.12479018"
./scripts/build_core_android.sh
```

Then build the APK:

```bash
gradle :app:testDebugUnitTest :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

The core and app are initially built for `arm64-v8a` only. Other ABIs are not enabled in the APK until matching PCSX ReARMed binaries are built and verified.

## Verification status

The host tests can be run with:

```bash
./scripts/test_libretro_frontend_host.sh
./scripts/test_native_bridge_host.sh
./scripts/test_core_binary_verifier.sh
./scripts/test_android_native_syntax.sh
./scripts/test_16kb_alignment_config.sh
./scripts/test_verify_apk.sh
./scripts/test_elf_alignment_verifier.sh
./scripts/archive_project_source.sh
```

The first test builds a fake Libretro core and verifies lifecycle, game load, input, video frame delivery and audio buffering. The second verifies JNI-to-frontend loading and the missing-core error path. These do not compile the actual PCSX ReARMed source or replace the Android NDK build. This environment has no Android SDK/NDK/Gradle installation and no outbound Git network access, so the upstream core build, APK build, and Infinix HOT 70 device test have not been run here.
