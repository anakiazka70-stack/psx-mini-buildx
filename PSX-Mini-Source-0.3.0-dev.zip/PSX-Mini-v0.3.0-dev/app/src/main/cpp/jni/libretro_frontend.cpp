#include "libretro_frontend.h"
#include "libretro_api_subset.h"

#include <algorithm>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <deque>
#include <fstream>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include <dlfcn.h>

namespace {
using ApiVersionFn = unsigned (*)();
using SetEnvironmentFn = void (*)(retro_environment_t);
using SetVideoRefreshFn = void (*)(retro_video_refresh_t);
using SetAudioSampleFn = void (*)(retro_audio_sample_t);
using SetAudioSampleBatchFn = void (*)(retro_audio_sample_batch_t);
using SetInputPollFn = void (*)(retro_input_poll_t);
using SetInputStateFn = void (*)(retro_input_state_t);
using InitFn = void (*)();
using DeinitFn = void (*)();
using GetSystemInfoFn = void (*)(retro_system_info *);
using GetSystemAvInfoFn = void (*)(retro_system_av_info *);
using LoadGameFn = bool (*)(const retro_game_info *);
using UnloadGameFn = void (*)();
using RunFn = void (*)();
using ResetFn = void (*)();
using SetControllerPortDeviceFn = void (*)(unsigned, unsigned);

struct CoreApi {
    ApiVersionFn api_version = nullptr;
    SetEnvironmentFn set_environment = nullptr;
    SetVideoRefreshFn set_video_refresh = nullptr;
    SetAudioSampleFn set_audio_sample = nullptr;
    SetAudioSampleBatchFn set_audio_sample_batch = nullptr;
    SetInputPollFn set_input_poll = nullptr;
    SetInputStateFn set_input_state = nullptr;
    InitFn init = nullptr;
    DeinitFn deinit = nullptr;
    GetSystemInfoFn get_system_info = nullptr;
    GetSystemAvInfoFn get_system_av_info = nullptr;
    LoadGameFn load_game = nullptr;
    UnloadGameFn unload_game = nullptr;
    RunFn run = nullptr;
    ResetFn reset = nullptr;
    SetControllerPortDeviceFn set_controller_port_device = nullptr;
};

std::mutex g_lifecycle_mutex;
std::mutex g_video_mutex;
std::mutex g_audio_mutex;
void *g_core_handle = nullptr;
CoreApi g_api;
bool g_core_initialized = false;
bool g_game_loaded = false;
bool g_need_fullpath = true;
std::string g_runtime_status = "Core not loaded.";
std::string g_system_dir;
std::string g_save_dir;
std::vector<uint8_t> g_game_data;
std::vector<uint8_t> g_video_data;
PsxMiniVideoInfo g_video_info{};
std::deque<int16_t> g_audio_queue;
uint16_t g_input_mask = 0;
int g_pixel_format = RETRO_PIXEL_FORMAT_0RGB1555;
double g_fps = 60.0;
double g_sample_rate = 44100.0;
std::unordered_map<std::string, std::string> g_option_values;

const char *safe_string(const char *value, const char *fallback) {
    return value != nullptr && value[0] != '\0' ? value : fallback;
}

std::string trim(std::string value) {
    const auto first = value.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = value.find_last_not_of(" \t\r\n");
    return value.substr(first, last - first + 1);
}

std::string default_option_value(const char *definition) {
    if (definition == nullptr) return {};
    const std::string text(definition);
    const auto semicolon = text.find(';');
    if (semicolon == std::string::npos) return {};
    std::string choices = trim(text.substr(semicolon + 1));
    const auto separator = choices.find('|');
    if (separator != std::string::npos) choices.resize(separator);
    return trim(choices);
}

void log_callback(retro_log_level level, const char *format, ...) {
    (void)level;
    if (format == nullptr) return;
    va_list args;
    va_start(args, format);
    std::vfprintf(stderr, format, args);
    va_end(args);
}

bool environment_callback(unsigned command, void *data) {
    switch (command) {
        case RETRO_ENVIRONMENT_GET_OVERSCAN:
            if (data) *static_cast<bool *>(data) = false;
            return true;
        case RETRO_ENVIRONMENT_GET_CAN_DUPE:
            if (data) *static_cast<bool *>(data) = true;
            return true;
        case RETRO_ENVIRONMENT_SET_MESSAGE:
            if (data) {
                const auto *message = static_cast<const retro_message *>(data);
                if (message->msg) g_runtime_status = std::string("Core: ") + message->msg;
            }
            return true;
        case RETRO_ENVIRONMENT_SHUTDOWN:
            g_runtime_status = "Core requested shutdown.";
            return true;
        case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
            if (data) *static_cast<const char **>(data) = g_system_dir.c_str();
            return true;
        case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
            if (data) *static_cast<const char **>(data) = g_save_dir.c_str();
            return true;
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
            if (!data) return false;
            {
                const int requested = *static_cast<const int *>(data);
                if (requested != RETRO_PIXEL_FORMAT_0RGB1555 &&
                    requested != RETRO_PIXEL_FORMAT_XRGB8888 &&
                    requested != RETRO_PIXEL_FORMAT_RGB565) return false;
                g_pixel_format = requested;
                return true;
            }
        case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
        case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
        case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
            return true;
        case RETRO_ENVIRONMENT_GET_VARIABLE:
            if (!data) return false;
            {
                auto *variable = static_cast<retro_variable *>(data);
                if (!variable->key) return false;
                const auto found = g_option_values.find(variable->key);
                variable->value = found == g_option_values.end() ? nullptr : found->second.c_str();
            }
            return true;
        case RETRO_ENVIRONMENT_SET_VARIABLES:
            if (!data) return false;
            {
                const auto *variables = static_cast<const retro_variable *>(data);
                for (size_t i = 0; variables[i].key != nullptr; ++i) {
                    if (g_option_values.find(variables[i].key) == g_option_values.end()) {
                        g_option_values.emplace(variables[i].key, default_option_value(variables[i].value));
                    }
                }
            }
            return true;
        case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
            if (data) *static_cast<bool *>(data) = false;
            return true;
        case RETRO_ENVIRONMENT_GET_LOG_INTERFACE:
            if (!data) return false;
            static_cast<retro_log_callback *>(data)->log = log_callback;
            return true;
        case RETRO_ENVIRONMENT_GET_LANGUAGE:
            if (data) *static_cast<unsigned *>(data) = 0; // English
            return true;
        case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS:
            if (data) *static_cast<bool *>(data) = true;
            return true;
        case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:
            if (data) *static_cast<unsigned *>(data) = 0; // request legacy SET_VARIABLES compatibility
            return true;
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS:
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL:
            // This frontend reports core-options API version 0 and supports SET_VARIABLES.
            return false;
        case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
            return true;
        case RETRO_ENVIRONMENT_SET_ROTATION:
            return false;
        case RETRO_ENVIRONMENT_SET_GEOMETRY:
            if (data) {
                const auto *geometry = static_cast<const retro_game_geometry *>(data);
                if (geometry->aspect_ratio > 0.0f) {
                    std::lock_guard<std::mutex> lock(g_video_mutex);
                    g_video_info.aspect_ratio = geometry->aspect_ratio;
                }
            }
            return true;
        case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO:
            if (data) {
                const auto *av = static_cast<const retro_system_av_info *>(data);
                if (av->timing.fps > 1.0 && av->timing.fps < 1000.0) g_fps = av->timing.fps;
                if (av->timing.sample_rate > 1000.0 && av->timing.sample_rate < 192000.0) g_sample_rate = av->timing.sample_rate;
            }
            return true;
        default:
            return false;
    }
}

void video_refresh_callback(const void *data, unsigned width, unsigned height, size_t pitch) {
    if (data == nullptr || width == 0 || height == 0 || width > 4096 || height > 4096) return;
    const size_t bytes_per_pixel = g_pixel_format == RETRO_PIXEL_FORMAT_XRGB8888 ? 4U : 2U;
    const size_t minimum_pitch = static_cast<size_t>(width) * bytes_per_pixel;
    constexpr size_t kMaxFrameBytes = 32U * 1024U * 1024U;
    if (pitch < minimum_pitch || pitch > kMaxFrameBytes / static_cast<size_t>(height)) return;
    const size_t bytes = pitch * static_cast<size_t>(height);
    std::lock_guard<std::mutex> lock(g_video_mutex);
    g_video_data.resize(bytes);
    std::memcpy(g_video_data.data(), data, bytes);
    g_video_info.width = width;
    g_video_info.height = height;
    g_video_info.pitch = pitch;
    g_video_info.data_size = bytes;
    g_video_info.pixel_format = g_pixel_format;
    if (g_video_info.aspect_ratio <= 0.0f) {
        g_video_info.aspect_ratio = static_cast<float>(width) / static_cast<float>(height);
    }
}

void audio_sample_callback(int16_t left, int16_t right) {
    std::lock_guard<std::mutex> lock(g_audio_mutex);
    constexpr size_t kMaxQueuedSamples = 176400;
    if (g_audio_queue.size() + 2 > kMaxQueuedSamples) {
        g_audio_queue.pop_front();
        if (!g_audio_queue.empty()) g_audio_queue.pop_front();
    }
    g_audio_queue.push_back(left);
    g_audio_queue.push_back(right);
}

size_t audio_sample_batch_callback(const int16_t *data, size_t frames) {
    if (!data || frames == 0) return 0;
    std::lock_guard<std::mutex> lock(g_audio_mutex);
    constexpr size_t kMaxQueuedSamples = 176400;
    const size_t samples = frames * 2;
    if (samples >= kMaxQueuedSamples) {
        g_audio_queue.clear();
        g_audio_queue.insert(g_audio_queue.end(), data + samples - kMaxQueuedSamples, data + samples);
        return frames;
    }
    while (g_audio_queue.size() + samples > kMaxQueuedSamples) {
        if (!g_audio_queue.empty()) g_audio_queue.pop_front();
        if (!g_audio_queue.empty()) g_audio_queue.pop_front();
    }
    g_audio_queue.insert(g_audio_queue.end(), data, data + samples);
    return frames;
}

void input_poll_callback() {}

int16_t input_state_callback(unsigned port, unsigned device, unsigned index, unsigned id) {
    (void)index;
    if (port != 0 || device != RETRO_DEVICE_JOYPAD) return 0;
    const uint16_t mask = static_cast<uint16_t>(__atomic_load_n(&g_input_mask, __ATOMIC_RELAXED));
    if (id == RETRO_DEVICE_ID_JOYPAD_MASK) return static_cast<int16_t>(mask);
    if (id >= 16) return 0;
    return (mask & (static_cast<uint16_t>(1U) << id)) != 0 ? 1 : 0;
}

template <typename T>
bool load_symbol(void *handle, const char *name, T *destination, bool required = true) {
    dlerror();
    void *symbol = dlsym(handle, name);
    const char *error = dlerror();
    if (symbol == nullptr || error != nullptr) {
        *destination = nullptr;
        if (required) {
            g_runtime_status = std::string("CORE_INCOMPATIBLE: missing ") + name + " export.";
            return false;
        }
        return true;
    }
    *destination = reinterpret_cast<T>(symbol);
    return true;
}

void reset_runtime_buffers() {
    {
        std::lock_guard<std::mutex> lock(g_video_mutex);
        g_video_data.clear();
        g_video_info = {};
    }
    {
        std::lock_guard<std::mutex> lock(g_audio_mutex);
        g_audio_queue.clear();
    }
    g_game_data.clear();
    g_pixel_format = RETRO_PIXEL_FORMAT_0RGB1555;
    g_fps = 60.0;
    g_sample_rate = 44100.0;
    g_option_values.clear();
}

void close_core_locked() {
    if (g_game_loaded && g_api.unload_game) g_api.unload_game();
    g_game_loaded = false;
    if (g_core_initialized && g_api.deinit) g_api.deinit();
    g_core_initialized = false;
    g_game_data.clear();
    if (g_core_handle) dlclose(g_core_handle);
    g_core_handle = nullptr;
    g_api = {};
    reset_runtime_buffers();
}
} // namespace

extern "C" const char *psxmini_load_core(const char *core_path, const char *system_dir, const char *save_dir) {
    std::lock_guard<std::mutex> lock(g_lifecycle_mutex);
    close_core_locked();
    if (!core_path || core_path[0] == '\0') {
        g_runtime_status = "CORE_NOT_FOUND: empty core path.";
        return g_runtime_status.c_str();
    }
    g_system_dir = safe_string(system_dir, "");
    g_save_dir = safe_string(save_dir, "");

    dlerror();
    g_core_handle = dlopen(core_path, RTLD_NOW | RTLD_LOCAL);
    if (!g_core_handle) {
        g_runtime_status = std::string("CORE_NOT_FOUND: ") + safe_string(dlerror(), "dlopen failed");
        return g_runtime_status.c_str();
    }

    bool ok = true;
    ok = load_symbol(g_core_handle, "retro_api_version", &g_api.api_version) && ok;
    ok = load_symbol(g_core_handle, "retro_set_environment", &g_api.set_environment) && ok;
    ok = load_symbol(g_core_handle, "retro_set_video_refresh", &g_api.set_video_refresh) && ok;
    ok = load_symbol(g_core_handle, "retro_set_audio_sample", &g_api.set_audio_sample) && ok;
    ok = load_symbol(g_core_handle, "retro_set_audio_sample_batch", &g_api.set_audio_sample_batch) && ok;
    ok = load_symbol(g_core_handle, "retro_set_input_poll", &g_api.set_input_poll) && ok;
    ok = load_symbol(g_core_handle, "retro_set_input_state", &g_api.set_input_state) && ok;
    ok = load_symbol(g_core_handle, "retro_init", &g_api.init) && ok;
    ok = load_symbol(g_core_handle, "retro_deinit", &g_api.deinit) && ok;
    ok = load_symbol(g_core_handle, "retro_get_system_info", &g_api.get_system_info) && ok;
    ok = load_symbol(g_core_handle, "retro_get_system_av_info", &g_api.get_system_av_info) && ok;
    ok = load_symbol(g_core_handle, "retro_load_game", &g_api.load_game) && ok;
    ok = load_symbol(g_core_handle, "retro_unload_game", &g_api.unload_game) && ok;
    ok = load_symbol(g_core_handle, "retro_run", &g_api.run) && ok;
    load_symbol(g_core_handle, "retro_reset", &g_api.reset, false);
    load_symbol(g_core_handle, "retro_set_controller_port_device", &g_api.set_controller_port_device, false);
    if (!ok) {
        if (g_core_handle) dlclose(g_core_handle);
        g_core_handle = nullptr;
        g_api = {};
        return g_runtime_status.c_str();
    }

    const unsigned api_version = g_api.api_version();
    if (api_version != RETRO_API_VERSION) {
        g_runtime_status = "CORE_INCOMPATIBLE: unsupported Libretro API version " + std::to_string(api_version) + ".";
        dlclose(g_core_handle);
        g_core_handle = nullptr;
        g_api = {};
        return g_runtime_status.c_str();
    }

    g_api.set_environment(environment_callback);
    g_api.set_video_refresh(video_refresh_callback);
    g_api.set_audio_sample(audio_sample_callback);
    g_api.set_audio_sample_batch(audio_sample_batch_callback);
    g_api.set_input_poll(input_poll_callback);
    g_api.set_input_state(input_state_callback);
    g_api.init();
    g_core_initialized = true;
    // Use the standard digital joypad on player 1. The export is optional for
    // compatibility with older cores; Libretro assumes a joypad by default.
    if (g_api.set_controller_port_device) {
        g_api.set_controller_port_device(0, RETRO_DEVICE_JOYPAD);
    }

    retro_system_info info{};
    g_api.get_system_info(&info);
    g_need_fullpath = info.need_fullpath;
    g_runtime_status = std::string("CORE_READY\nAPI: 1\nName: ") + safe_string(info.library_name, "Unknown core") +
        "\nVersion: " + safe_string(info.library_version, "Unknown version") +
        "\nExtensions: " + safe_string(info.valid_extensions, "Not reported") +
        "\nNeeds full path: " + (g_need_fullpath ? "yes" : "no");
    return g_runtime_status.c_str();
}

extern "C" const char *psxmini_load_game(const char *content_path) {
    std::lock_guard<std::mutex> lock(g_lifecycle_mutex);
    if (!g_core_initialized || !g_api.load_game) {
        g_runtime_status = "GAME_LOAD_FAILED: load a compatible core first.";
        return g_runtime_status.c_str();
    }
    if (g_game_loaded && g_api.unload_game) g_api.unload_game();
    g_game_loaded = false;
    g_game_data.clear();
    if (!content_path || content_path[0] == '\0') {
        g_runtime_status = "GAME_LOAD_FAILED: empty content path.";
        return g_runtime_status.c_str();
    }

    retro_game_info game{};
    game.path = content_path;
    if (!g_need_fullpath) {
        std::ifstream input(content_path, std::ios::binary);
        if (!input) {
            g_runtime_status = "GAME_LOAD_FAILED: could not open content file.";
            return g_runtime_status.c_str();
        }
        g_game_data.assign(std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>());
        if (g_game_data.empty()) {
            g_runtime_status = "GAME_LOAD_FAILED: content file is empty.";
            return g_runtime_status.c_str();
        }
        game.data = g_game_data.data();
        game.size = g_game_data.size();
    }

    if (!g_api.load_game(&game)) {
        g_runtime_status = "GAME_LOAD_FAILED: core rejected the selected game image. Check the CUE and track files.";
        g_game_data.clear();
        return g_runtime_status.c_str();
    }
    g_game_loaded = true;

    retro_system_av_info av{};
    g_api.get_system_av_info(&av);
    if (av.timing.fps > 1.0 && av.timing.fps < 1000.0) g_fps = av.timing.fps;
    if (av.timing.sample_rate > 1000.0 && av.timing.sample_rate < 192000.0) g_sample_rate = av.timing.sample_rate;
    {
        std::lock_guard<std::mutex> video_lock(g_video_mutex);
        if (g_video_info.aspect_ratio <= 0.0f) {
            g_video_info.aspect_ratio = av.geometry.aspect_ratio > 0.0f ? av.geometry.aspect_ratio : 4.0f / 3.0f;
        }
    }
    g_runtime_status = "GAME_LOADED\nContent: " + std::string(content_path) +
        "\nFPS: " + std::to_string(g_fps) + "\nAudio: " + std::to_string(g_sample_rate) + " Hz";
    return g_runtime_status.c_str();
}

extern "C" void psxmini_run_frame(void) {
    if (g_game_loaded && g_api.run) g_api.run();
}

extern "C" void psxmini_unload_game(void) {
    std::lock_guard<std::mutex> lock(g_lifecycle_mutex);
    if (g_game_loaded && g_api.unload_game) g_api.unload_game();
    g_game_loaded = false;
    g_game_data.clear();
    {
        std::lock_guard<std::mutex> video_lock(g_video_mutex);
        g_video_data.clear();
        g_video_info = {};
    }
    {
        std::lock_guard<std::mutex> audio_lock(g_audio_mutex);
        g_audio_queue.clear();
    }
    g_runtime_status = "Game unloaded.";
}

extern "C" void psxmini_shutdown(void) {
    std::lock_guard<std::mutex> lock(g_lifecycle_mutex);
    close_core_locked();
    g_runtime_status = "Core shut down.";
}

extern "C" void psxmini_set_input_mask(uint16_t mask) {
    __atomic_store_n(&g_input_mask, mask, __ATOMIC_RELAXED);
}

extern "C" bool psxmini_is_core_loaded(void) { return g_core_initialized; }
extern "C" bool psxmini_is_game_loaded(void) { return g_game_loaded; }
extern "C" double psxmini_get_frame_rate(void) { return g_fps; }
extern "C" double psxmini_get_sample_rate(void) { return g_sample_rate; }

extern "C" int psxmini_get_video_info(PsxMiniVideoInfo *info) {
    if (!info) return 0;
    std::lock_guard<std::mutex> lock(g_video_mutex);
    if (g_video_data.empty() || g_video_info.width == 0 || g_video_info.height == 0) return 0;
    *info = g_video_info;
    return 1;
}

extern "C" size_t psxmini_copy_video_frame(uint8_t *destination, size_t capacity) {
    std::lock_guard<std::mutex> lock(g_video_mutex);
    if (g_video_data.empty()) return 0;
    if (!destination || capacity < g_video_data.size()) return g_video_data.size();
    std::memcpy(destination, g_video_data.data(), g_video_data.size());
    return g_video_data.size();
}

extern "C" size_t psxmini_pull_audio(int16_t *destination, size_t max_samples) {
    if (!destination || max_samples == 0) return 0;
    std::lock_guard<std::mutex> lock(g_audio_mutex);
    const size_t count = std::min(max_samples, g_audio_queue.size());
    for (size_t i = 0; i < count; ++i) {
        destination[i] = g_audio_queue.front();
        g_audio_queue.pop_front();
    }
    return count;
}

extern "C" const char *psxmini_get_runtime_status(void) { return g_runtime_status.c_str(); }
