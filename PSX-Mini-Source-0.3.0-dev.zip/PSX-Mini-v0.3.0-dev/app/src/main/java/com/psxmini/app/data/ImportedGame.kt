package com.psxmini.app.data

import java.io.File

data class ImportedGame(
    val folder: File,
    val displayName: String,
    val mainFile: File,
    val format: String,
    val cueComplete: Boolean
)
