#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

struct PsxMiniVideoInfo {
    unsigned width;
    unsigned height;
    size_t pitch;
    size_t data_size;
    int pixel_format;
    float aspect_ratio;
};

const char *psxmini_load_core(const char *core_path, const char *system_dir, const char *save_dir);
const char *psxmini_load_game(const char *content_path);
void psxmini_run_frame(void);
void psxmini_unload_game(void);
void psxmini_shutdown(void);
void psxmini_set_input_mask(uint16_t mask);
bool psxmini_is_core_loaded(void);
bool psxmini_is_game_loaded(void);
double psxmini_get_frame_rate(void);
double psxmini_get_sample_rate(void);
int psxmini_get_video_info(struct PsxMiniVideoInfo *info);
size_t psxmini_copy_video_frame(uint8_t *destination, size_t capacity);
size_t psxmini_pull_audio(int16_t *destination, size_t max_samples);
const char *psxmini_get_runtime_status(void);

#ifdef __cplusplus
}
#endif
