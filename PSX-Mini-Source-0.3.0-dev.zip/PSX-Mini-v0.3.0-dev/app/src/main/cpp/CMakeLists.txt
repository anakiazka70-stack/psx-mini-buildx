cmake_minimum_required(VERSION 3.22.1)
project(psxmini_native LANGUAGES CXX)

add_library(psxmini_native SHARED
    jni/native_bridge.cpp
    jni/libretro_frontend.cpp
)

target_include_directories(psxmini_native PRIVATE include)
target_compile_features(psxmini_native PRIVATE cxx_std_17)
target_compile_options(psxmini_native PRIVATE
    -Wall
    -Wextra
    -Wpedantic
)

if(ANDROID)
    target_link_options(psxmini_native PRIVATE
        "-Wl,-z,max-page-size=16384"
        "-Wl,-z,common-page-size=16384"
    )
endif()

find_library(android_log log)
find_library(android_dl dl)
if(ANDROID)
    find_library(android_native android)
    target_link_libraries(psxmini_native PRIVATE ${android_log} ${android_dl} ${android_native})
else()
    target_link_libraries(psxmini_native PRIVATE ${android_log} ${android_dl})
endif()
