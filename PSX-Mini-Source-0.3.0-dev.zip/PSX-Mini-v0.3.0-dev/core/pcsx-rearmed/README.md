# PCSX ReARMed upstream dependency

The PSX Mini native frontend now includes a Libretro runtime adapter. The emulator core itself is fetched at build time rather than copied into this source archive, keeping the project package smaller while pinning the exact upstream revision in `UPSTREAM.lock`.

The build script uses the upstream Android NDK project under `jni/Android.mk` and `jni/Application.mk`, then stages the generated `libretro.so` as `libpcsx_rearmed_libretro.so` for the Android app. The pinned Android.mk defines `LOCAL_MODULE := retro`.

The current frontend has been exercised against a purpose-built fake Libretro core on the host. That validates the runtime callback/data path but does not prove that this exact PCSX ReARMed revision builds with the configured NDK, links into the APK, or boots Pepsi Man on a real device. Those checks remain pending in GitHub Actions and on Android hardware.

PCSX ReARMed is GPL-2.0. When distributing an APK containing this core, provide the exact corresponding core source, license, copyright notices, and any required modifications under the license terms. No BIOS or game image is bundled.
