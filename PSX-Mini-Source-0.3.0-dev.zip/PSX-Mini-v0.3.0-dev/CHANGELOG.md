# Changelog

## 0.3.0-dev

- Aligns the Android APK ABI filter with the packaged PCSX ReARMed core (`arm64-v8a`) so the initial release target cannot install a frontend-only ABI variant.
- Adds ELF architecture and required Libretro export verification for built core binaries.
- Adds APK verification that both `libpsxmini_native.so` and `libpcsx_rearmed_libretro.so` are packaged for the target ABI.
- Adds host tests for complete, incomplete, and wrong-ABI core binaries.
- Adds a host-stub syntax check for Android-specific JNI/ANativeWindow code.
- Updates the compatible Gradle runtime to 8.14.8.
- Makes the upstream ndk-build use an explicit static C++ runtime for reproducible core packaging.
- Adds 16 KB ELF alignment flags to the PSX Mini CMake library and applies a reproducible `common-page-size=16384` patch to the pinned core build.
- Verifies every ARM64 PT_LOAD segment meets the 16 KB alignment requirement before packaging.
- Updates app/native version metadata and player copy for the current development milestone.
- Restricts the app ABI filter to arm64-v8a so the initial APK cannot be produced without its matching core.
- Adds a regression test for both 16 KB linker flags and the pinned-core Android.mk patch.
- Switches native libraries to uncompressed APK packaging and adds a 16 KB zipalign verification gate.
- Extends the ARM64 ELF verifier to check GNU_RELRO boundaries under Android 16 KB page-size rules.
- Adds APK-package test coverage for required native libraries and the zipalign command path.
- Adds positive and negative regression fixtures for PT_LOAD and GNU_RELRO 16 KB alignment verification.
- Updates local build instructions to the Gradle 8.14.8 toolchain.


## 0.2.1-dev

- Rewrites imported CUE track references to the exact on-disk filename case, preventing case-sensitive Android path failures for Windows-authored CUE sheets.
- Adds host-smoke coverage for case-normalized CUE track references.
- Keeps the player screen awake while a game is running.
- Updates source and app version metadata for the next development snapshot.

## 0.2.0-dev

- Added the Libretro runtime loader with required export and API version checks.
- Added Libretro environment, software-video, audio, input-poll and joypad callbacks.
- Added legacy core-option defaults, system/save directory callbacks and AV timing.
- Added full-path and in-memory game loading, plus a `retro_run()` frame loop.
- Added Android `ANativeWindow` RGB565 presentation and Android `AudioTrack` output.
- Added a landscape player screen with digital touch controls and Play action in the library.
- Added player-1 joypad selection when the core exports `retro_set_controller_port_device`.
- Fixed the home screen core-ready check to recognize the frontend status string.
- Replaced startup core initialization with a cheap packaged-file check to avoid races with the player, and clears joypad state on player exit.
- Hardened software-frame validation against undersized pitch and oversized buffers.
- Expanded fake-core host tests for lifecycle, input, video, audio and controller selection.
- Rewrites directory-qualified CUE track paths when imported files are staged into a flat private folder.
- Prevents launching a standalone BIN without a matching CUE sheet.
- BIOS importer stages user-selected firmware in the core system directory.
- Rewrote technical documentation to separate tested frontend behavior from unverified core/device work.

## 0.1.3-dev

- Added a reproducible PCSX ReARMed upstream commit pin.
- Added a build script using the upstream Android NDK `jni/Android.mk` project.
- Added arm64-v8a core packaging to the GitHub Actions build workflow.
- Added GPL license copying and a matching upstream source archive to CI artifacts.
- Added a JNI Libretro API metadata probe.
- Added a host test using a fake Libretro shared library.

## 0.1.2-dev

- Added a C++17 JNI bridge and basic native build/ABI reporting.
- Added host C++ build and Java JNI smoke test.

## 0.1.1-dev

- Added an Android APK GitHub Actions workflow.
- Added CUE validator test coverage and import-path fixes.

## 0.1.0-dev

- Created the Android frontend shell, SAF importer, private game staging, and CUE track validation.
