# Libretro API declarations

The native frontend uses a minimal ABI declaration subset at `app/src/main/cpp/include/libretro_api_subset.h`. It preserves the MIT notice and copyright attribution for the Libretro API. The canonical, full API header is maintained by the Libretro project at:

https://github.com/libretro/libretro-common/blob/master/include/libretro.h

When expanding callback or option support, compare this subset with the canonical header and preserve its MIT notice. The frontend currently reports core-options API version 0 and supports legacy `SET_VARIABLES` defaults only.
