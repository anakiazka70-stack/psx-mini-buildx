# PSX Mini — Spesifikasi Teknis

**Versi source:** `0.3.0-dev`  
**Target perangkat pertama:** Android, dengan pengujian sasaran Infinix HOT 70  
**Core PS1:** PCSX ReARMed melalui Libretro API  
**Game uji:** Pepsi Man (file disediakan pengguna)  
**Status:** frontend Libretro awal terimplementasi; build core asli, APK, dan uji perangkat belum diverifikasi.

---

## 1. Tujuan dan ruang lingkup

PSX Mini adalah frontend emulator PlayStation 1 untuk Android. Aplikasi Android ditulis dengan Kotlin; frontend native ditulis dengan C++17/JNI; mesin emulasi disediakan oleh core PCSX ReARMed yang menggunakan API Libretro.

PSX Mini bukan emulator PS1 yang ditulis dari nol dan bukan aplikasi RetroArch. Proyek ini meng-host core Libretro sendiri dan menyediakan antarmuka Android, impor game, kontrol sentuh, output video/audio, serta pengelolaan data aplikasi.

## 2. Status implementasi v0.3.0-dev

### Sudah dibuat

- Android home/library UI dan halaman player landscape.
- Home screen checks for the packaged core file; actual native initialization happens only in the player worker thread.
- Import game dan BIOS opsional menggunakan Android Storage Access Framework (SAF); tidak meminta akses seluruh penyimpanan.
- Penyalinan file game ke penyimpanan privat aplikasi, normalisasi path track CUE saat file diratakan ke satu folder, pencocokan nama track tanpa membedakan kapitalisasi, dan penulisan ulang sesuai ejaan nama file aktual di penyimpanan Android.
- C++17/JNI dynamic loader untuk shared library core Libretro.
- Resolusi simbol API Libretro yang diperlukan, pemeriksaan API version, dan callback environment, video, audio, input poll, serta input state.
- Dukungan environment awal: direktori system/save, pixel format software, pesan core, log, legacy core options, AV info, input bitmask, dan controller port joypad standar bila core menyediakan fungsi tersebut.
- Mode pemuatan konten full-path atau buffer memori sesuai `need_fullpath` dari core.
- Pemanggilan `retro_run()` pada thread emulasi player.
- Buffer audio native dan jalur output software framebuffer ke Android `Surface` melalui `ANativeWindow` dengan output RGB565.
- Kontrol sentuh untuk tombol digital RetroPad; layar dijaga tetap aktif selama gameplay.
- Uji host terhadap core tiruan: load core/game, callback, input, frame video, audio, unload, shutdown, dan panggilan JNI.
- Verifikasi ELF untuk ABI ARM64, 14 ekspor Libretro wajib, alignment `PT_LOAD` minimal 16 KB, dan batas `GNU_RELRO` sesuai panduan 16 KB Android.
- Build APK dibatasi ke ABI `arm64-v8a` agar frontend native dan core PS1 selalu dipaketkan sebagai pasangan.
- Verifikasi APK untuk dua native library wajib dan alignment ZIP 16 KB melalui `zipalign -c -P 16 4`.
- CI mengarsipkan source frontend dan source PCSX ReARMed yang sesuai dengan APK untuk kepatuhan GPL.

### Belum diverifikasi

- Build PCSX ReARMed asli untuk Android NDK/ARM64.
- Build APK dengan Android Gradle Plugin/Gradle/SDK dan pemeriksaan zipalign 16 KB.
- Instalasi dan runtime di Infinix HOT 70.
- Output Surface/AudioTrack pada perangkat sesungguhnya.
- Boot dan gameplay Pepsi Man dengan HLE BIOS atau BIOS pengguna.

Uji core tiruan membuktikan jalur frontend dasar pada host, bukan kompatibilitas core PCSX ReARMed atau kemampuan menjalankan game.

## 3. Stack teknologi

| Area | Implementasi / keputusan |
|---|---|
| Aplikasi Android | Kotlin |
| UI | Android View system |
| Native frontend | C++17 dan JNI |
| Build native aplikasi | CMake melalui Gradle ExternalNativeBuild |
| Core API | Subset ABI Libretro API dengan notice MIT |
| Mesin PS1 | PCSX ReARMed, GPL-2.0 |
| Video awal | Software framebuffer → `ANativeWindow` RGB565 |
| Audio awal | Libretro PCM callback → native queue → Android `AudioTrack` |
| Impor | Android SAF / document picker |
| ABI core pertama | `arm64-v8a` |
| Native ELF page alignment | 16 KB (`PT_LOAD`) |
| APK native library packaging | Uncompressed; 16 KB zipalign verification |

## 4. Core dan lisensi

Core yang dipilih adalah repository resmi `https://github.com/libretro/pcsx_rearmed` pada commit yang dikunci di `core/pcsx-rearmed/UPSTREAM.lock`.

Build script menggunakan build Android NDK upstream di folder `jni/`. Android.mk pada commit tersebut mendeklarasikan modul native bernama `retro`, sehingga output yang diharapkan adalah `libretro.so`, lalu disalin ke nama paket PSX Mini `libpcsx_rearmed_libretro.so`.

PCSX ReARMed berlisensi GPL-2.0. Distribusi APK yang menyertakan core harus disertai source yang sesuai, lisensi, copyright notice, dan patch yang diwajibkan lisensi. Subset header API Libretro mempertahankan notice MIT. Jangan menyertakan BIOS PS1, image game, firmware Sony, atau cover art berhak cipta ke source/ APK.

## 5. Struktur proyek

```text
PSX-Mini/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/psxmini/app/
│       │   ├── MainActivity.kt
│       │   ├── data/                 # Game repository dan validasi CUE
│       │   ├── storage/              # SAF picker dan staging file
│       │   ├── emulator/             # JNI bridge dan controller
│       │   └── player/PlayerActivity.kt
│       └── cpp/
│           ├── CMakeLists.txt
│           ├── include/              # Libretro API subset dan frontend API
│           └── jni/                  # JNI bridge dan Libretro frontend runtime
├── core/
│   ├── libretro-api/                 # Catatan API dan referensi header
│   └── pcsx-rearmed/                 # Pin source upstream dan petunjuk build
├── docs/                             # Arsitektur, build, runtime, tes, lisensi
├── scripts/                          # Build core dan host smoke tests
└── .github/workflows/                 # Build APK melalui GitHub Actions
```

## 6. Siklus runtime

1. `PlayerActivity` memulai worker thread.
2. JNI memuat `libpcsx_rearmed_libretro.so` dengan `dlopen()`.
3. Frontend mencari simbol `retro_*`, memeriksa API version 1, lalu mendaftarkan callback.
4. Core diinisialisasi dan player 1 disetel ke joypad digital standar jika fungsi controller-port tersedia.
5. Frontend mengirim path game atau buffer file ke `retro_load_game()` sesuai `need_fullpath`.
6. Worker memanggil `retro_run()` berulang kali.
7. Callback video menyimpan framebuffer; JNI mengubahnya ke output RGB565 dan menggambar ke Android `Surface`.
8. Callback audio menaruh stereo PCM 16-bit pada antrean terbatas; Kotlin mengirimkannya ke `AudioTrack`.
9. Callback input membaca bitmask joypad yang diperbarui dari tombol layar.
10. Saat keluar, game di-unload, core di-deinit, lalu shared library ditutup.

Semua operasi lifecycle core dan `retro_run()` harus berlangsung pada worker emulasi yang sama. Callback video/audio dapat menggunakan antrean atau mutex terpisah, dan event UI hanya memperbarui input/surface.

## 7. Impor game dan penyimpanan

PSX Mini menggunakan Android SAF untuk meminta akses hanya pada file yang dipilih. Aplikasi tidak meminta `MANAGE_EXTERNAL_STORAGE`.

Format yang direncanakan/ditangani oleh library importer mengikuti ekstensi file yang didukung core. Untuk disc BIN/CUE, pengguna harus memilih file CUE dan seluruh track yang dirujuknya. Aplikasi meratakan path track pada entri `FILE` agar cocok dengan file yang disalin, memeriksa setiap referensi setelah impor, dan tidak menawarkan Play untuk file BIN tanpa CUE yang cocok.

Lokasi penyimpanan privat aplikasi:

```text
files/
├── games/<game-id>/       # File game hasil impor
├── system/                # BIOS yang diimpor pengguna; tidak dibundel
└── saves/                 # Direktori save yang diserahkan ke core
```

Folder `states/` dan UI memory-card/save-state terpisah masih merupakan pekerjaan lanjutan; belum boleh dianggap sudah didukung penuh hanya karena core mampu menyediakan API tersebut.

## 8. BIOS dan konten

- Tidak ada BIOS atau game yang disertakan di repository atau APK.
- Aplikasi menyediakan impor file BIOS opsional yang dipilih pengguna.
- Jika BIOS yang cocok tidak tersedia, PCSX ReARMed dapat menggunakan HLE BIOS, tetapi dokumentasi core menjelaskan bahwa kompatibilitasnya lebih rendah dan sejumlah game dapat mengalami masalah.
- Aplikasi tidak menyediakan link unduhan BIOS.

## 9. Batasan frontend saat ini

- Environment API lanjutan seperti hardware rendering, VFS penuh, disk control, rumble, achievements, netplay, serta core-options v1/v2 belum diimplementasikan.
- Core options yang didukung saat ini hanya jalur legacy `SET_VARIABLES` dan default value; belum ada halaman pengaturan yang menyimpan override pengguna.
- Rendering masih software framebuffer dengan nearest-neighbor scaling; belum ada shader atau OpenGL renderer.
- UI save state, pengelolaan memory card, pause/resume, fast-forward, gamepad eksternal, dan multi-controller belum tersedia.
- Timing audio/video, penggunaan memori, stabilitas, dan performa harus diukur pada perangkat Android nyata.

## 10. Toolchain dan build

Toolchain yang dikonfigurasi pada proyek saat ini:

- JDK 17
- Gradle 8.14.8
- Android Gradle Plugin 8.13.2
- Kotlin Gradle Plugin 2.3.21
- Android SDK Platform 36 / target SDK 35 / min SDK 24
- Android NDK 27.2.12479018
- CMake 3.22.1

Build core dan APK:

```bash
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/27.2.12479018"
./scripts/build_core_android.sh
./scripts/test_libretro_frontend_host.sh
./scripts/test_native_bridge_host.sh
gradle :app:testDebugUnitTest :app:assembleDebug
```

Workflow GitHub Actions menjalankan dua host smoke tests, membangun core ARM64 dari commit yang dipin, lalu membangun APK debug dan mengunggah APK bersama source core GPL terkait.

## 11. Hasil pengujian yang tersedia

| Pemeriksaan | Status saat paket ini dibuat |
|---|---|
| Fake Libretro core lifecycle test | Lulus di host |
| Fake core video/audio/input test | Lulus di host |
| JNI host smoke test | Lulus di host |
| CUE path-flattening smoke test | Lulus dengan Kotlin compiler di host |
| Shell syntax validation | Lulus |
| Android JNI branch syntax dengan stub API | Lulus pemeriksaan sintaks, bukan NDK build |
| PCSX ReARMed Android NDK build | Belum dijalankan |
| Gradle/Android APK build | Belum dijalankan |
| Infinix HOT 70 test | Belum dijalankan |
| Pepsi Man gameplay test | Belum dijalankan |

## 12. Roadmap

1. Jalankan GitHub Actions untuk memverifikasi build core PCSX ReARMed ARM64 dan build APK.
2. Perbaiki error build/ABI bila ditemukan dari log CI.
3. Instal APK hasil build pada perangkat Android arm64.
4. Uji SAF importer untuk file Pepsi Man BIN/CUE.
5. Uji HLE BIOS dan gameplay sesungguhnya; bila perlu, uji dengan BIOS yang pengguna berhak gunakan.
6. Setelah boot stabil, tambahkan penyimpanan, state, pengaturan kontrol, core options, serta peningkatan video secara bertahap.

## Referensi teknis

- PCSX ReARMed core docs: https://docs.libretro.com/library/pcsx_rearmed/
- Libretro core development: https://docs.libretro.com/development/cores/developing-cores/
- Canonical Libretro header: https://github.com/libretro/libretro-common/blob/master/include/libretro.h
- Android Storage Access Framework: https://developer.android.com/training/data-storage/shared/documents-files
- Android NDK CMake: https://developer.android.com/ndk/guides/cmake
