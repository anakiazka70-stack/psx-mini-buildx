package com.psxmini.app.data

import java.io.File

object CueValidator {
    private val fileLine = Regex(
        "(?i)^(\\s*FILE\\s+)(?:\"([^\"]+)\"|(.+?))(\\s+(?:BINARY|MOTOROLA|WAVE|MP3|AIFF|FLAC)\\s*)$"
    )

    /**
     * The importer stages selected files together in one private folder. Rewrite
     * directory-qualified FILE entries to their basename so the CUE continues to
     * reference the copied files after staging/flattening.
     */
    fun flattenTrackReferences(cueFile: File): Int {
        if (!cueFile.isFile) return 0
        val originalLines = runCatching { cueFile.readLines() }.getOrElse { return 0 }
        var changed = 0
        val rewritten = originalLines.map { line ->
            val match = fileLine.matchEntire(line) ?: return@map line
            val quotedPath = match.groupValues[2]
            val unquotedPath = match.groupValues[3]
            val originalPath = if (quotedPath.isNotBlank()) quotedPath else unquotedPath.trim()
            val requestedName = originalPath.replace('\\', '/').substringAfterLast('/')
            if (requestedName.isBlank()) {
                line
            } else {
                // Android's app-private storage is case-sensitive. Resolve the copied
                // file's actual spelling case-insensitively so a CUE made on Windows
                // does not pass validation but fail to open its track on Android.
                val actualName = cueFile.parentFile?.listFiles()
                    ?.firstOrNull { it.isFile && it.name.equals(requestedName, ignoreCase = true) }
                    ?.name ?: requestedName
                if (actualName == originalPath) {
                    line
                } else {
                    changed += 1
                    val pathToken = if (quotedPath.isNotBlank()) "\"$actualName\"" else actualName
                    match.groupValues[1] + pathToken + match.groupValues[4]
                }
            }
        }
        if (changed > 0) {
            runCatching { cueFile.writeText(rewritten.joinToString(separator = "\n", postfix = "\n")) }
                .onFailure { return 0 }
        }
        return changed
    }

    fun missingTracks(cueFile: File): List<String> {
        if (!cueFile.isFile) return listOf(cueFile.name)
        val references = runCatching {
            cueFile.useLines { lines ->
                lines.mapNotNull { line ->
                    val match = fileLine.matchEntire(line) ?: return@mapNotNull null
                    (match.groupValues[2].ifBlank { match.groupValues[3] }).trim().trim('"')
                }.toList()
            }
        }.getOrElse { return listOf("CUE could not be read") }

        if (references.isEmpty()) return listOf("No FILE entries found in CUE")

        val present = cueFile.parentFile?.listFiles()
            ?.map { it.name.lowercase() }
            ?.toSet()
            .orEmpty()
        return references.filter { reference ->
            val fileName = reference.replace('\\', '/').substringAfterLast('/')
            fileName.lowercase() !in present
        }
    }
}
