package com.psxmini.app.data

import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class CueValidatorTest {
    @get:Rule
    val temporaryFolder = TemporaryFolder()

    @Test
    fun reportsNoMissingTrackWhenQuotedTrackExists() {
        val folder = temporaryFolder.newFolder("disc")
        val track = folder.resolve("Pepsi Man.bin").apply { writeBytes(byteArrayOf(1, 2, 3)) }
        val cue = folder.resolve("Pepsi Man.cue").apply {
            writeText("FILE \"${track.name}\" BINARY\n  TRACK 01 MODE2/2352\n    INDEX 01 00:00:00\n")
        }

        assertEquals(emptyList<String>(), CueValidator.missingTracks(cue))
    }

    @Test
    fun reportsMissingTrackByName() {
        val folder = temporaryFolder.newFolder("missing")
        val cue = folder.resolve("Pepsi Man.cue").apply {
            writeText("FILE \"Pepsi Man.bin\" BINARY\n  TRACK 01 MODE2/2352\n")
        }

        assertEquals(listOf("Pepsi Man.bin"), CueValidator.missingTracks(cue))
    }

    @Test
    fun normalizesWindowsPathSeparatorsInCueReferences() {
        val folder = temporaryFolder.newFolder("windows-path")
        folder.resolve("track01.bin").writeBytes(byteArrayOf(1, 2, 3))
        val cue = folder.resolve("disc.cue").apply {
            writeText("FILE \"tracks\\track01.bin\" BINARY\n  TRACK 01 MODE2/2352\n")
        }

        assertEquals(emptyList<String>(), CueValidator.missingTracks(cue))
    }

    @Test
    fun flattensDirectoryQualifiedTrackPathsAfterImport() {
        val folder = temporaryFolder.newFolder("flatten")
        folder.resolve("track01.bin").writeBytes(byteArrayOf(1, 2, 3))
        val cue = folder.resolve("disc.cue").apply {
            writeText("FILE \"tracks\\track01.bin\" BINARY\n  TRACK 01 MODE2/2352\n")
        }

        assertEquals(1, CueValidator.flattenTrackReferences(cue))
        assertEquals(emptyList<String>(), CueValidator.missingTracks(cue))
        assertEquals("FILE \"track01.bin\" BINARY", cue.readLines().first())
    }


    @Test
    fun rewritesTrackReferenceToActualOnDiskCase() {
        val folder = temporaryFolder.newFolder("case-fix")
        folder.resolve("Track01.BIN").writeBytes(byteArrayOf(1, 2, 3))
        val cue = folder.resolve("disc.cue").apply {
            writeText("FILE \"track01.bin\" BINARY\n  TRACK 01 MODE2/2352\n")
        }

        assertEquals(1, CueValidator.flattenTrackReferences(cue))
        assertEquals("FILE \"Track01.BIN\" BINARY", cue.readLines().first())
        assertEquals(emptyList<String>(), CueValidator.missingTracks(cue))
    }

    @Test
    fun reportsCueWithoutFileEntries() {
        val cue = temporaryFolder.newFile("empty.cue").apply { writeText("REM no tracks\n") }
        assertEquals(listOf("No FILE entries found in CUE"), CueValidator.missingTracks(cue))
    }
}
