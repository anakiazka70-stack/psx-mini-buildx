package com.psxmini.app.data

import android.content.Context
import java.io.File
import java.util.Locale

class GameRepository(context: Context) {
    private val gamesDir = File(context.filesDir, "games")

    fun listGames(): List<ImportedGame> {
        if (!gamesDir.exists()) return emptyList()
        return gamesDir.listFiles()
            ?.filter { it.isDirectory }
            ?.mapNotNull { folder ->
                val files = folder.listFiles()?.filter { it.isFile }.orEmpty()
                val main = files.sortedBy { file ->
                    when (file.extension.lowercase(Locale.ROOT)) {
                        "cue" -> 0
                        "chd", "pbp", "iso", "img", "mds", "ccd" -> 1
                        "bin" -> 2
                        else -> 3
                    }
                }.firstOrNull() ?: return@mapNotNull null
                val cue = files.firstOrNull { it.extension.equals("cue", ignoreCase = true) }
                // PCSX ReARMed expects BIN disc data to be described by a CUE sheet.
                // A bare .bin should remain in the library but not expose Play yet.
                val cueComplete = when {
                    cue != null -> CueValidator.missingTracks(cue).isEmpty()
                    main.extension.equals("bin", ignoreCase = true) -> false
                    else -> true
                }
                ImportedGame(
                    folder = folder,
                    displayName = main.nameWithoutExtension.replace('_', ' '),
                    mainFile = main,
                    format = main.extension.uppercase(Locale.ROOT).ifBlank { "UNKNOWN" },
                    cueComplete = cueComplete
                )
            }
            ?.sortedByDescending { it.folder.lastModified() }
            .orEmpty()
    }

    companion object {
        val supportedExtensions = setOf("cue", "bin", "img", "iso", "chd", "pbp", "mdf", "mds", "ccd", "sub")
    }
}
