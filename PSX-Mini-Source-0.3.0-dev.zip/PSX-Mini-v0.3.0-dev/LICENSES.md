# License plan and compliance notes

The PSX Mini frontend source in this development archive has no final project-wide license declaration yet. Choose and add a root `LICENSE` before public redistribution.

The selected emulator dependency, PCSX ReARMed, is GPL-2.0. If it is integrated and distributed in the same application package, the distribution model and obligations must be reviewed carefully. The distribution must provide the corresponding source code and notices required by the applicable GPL terms, including local modifications and build scripts where required. The GitHub Actions artifact therefore includes the exact pinned upstream source archive for the core.

The Libretro API declarations subset is covered by the MIT notice preserved in `app/src/main/cpp/include/libretro_api_subset.h` and `THIRD_PARTY_NOTICES.md`.

Do not assume that using an open-source emulator core makes the entire Android application automatically free of licensing obligations. Do not bundle BIOS firmware, game images, Sony trademarks/assets, or copyrighted cover art.
