# PSX Mini Technical Specification — current implementation

The original design decisions and broader roadmap are preserved in the project root as `PSX_Mini_Technical_Spec.md`.

## Implemented in v0.3.0-dev

- Native Android app shell using Kotlin and the Android View system.
- SAF file picker and private-storage staging for disc images and user-provided BIOS files.
- CUE track reference validation and normalization to the copied file’s exact on-disk case.
- JNI/C++17 Libretro runtime loader and API version check.
- Libretro environment, software video, audio and joypad input callbacks.
- Core initialization, game loading, `retro_run()` frame execution, unload and deinitialization.
- Android Surface output through `ANativeWindow` and RGB565 software scaling.
- Android `AudioTrack` output from the native batch-audio queue.
- Landscape player screen with touch joypad buttons and Play action in the library.
- Host fake-core runtime and JNI smoke tests.
- ARM64 ELF architecture and required Libretro export checks.
- 16 KB PT_LOAD and GNU_RELRO alignment checks for ARM64 native libraries.
- Uncompressed native-library APK packaging and 16 KB ZIP alignment verification through `zipalign -c -P 16 4`.
- Final APK check for matching frontend/core libraries and separate frontend/core source archives in CI.

## Not verified / not implemented yet

- Actual Android NDK build of the pinned PCSX ReARMed core with the 16 KB alignment patch.
- Successful APK build, installation, or runtime verification on the Infinix HOT 70.
- Pepsi Man boot/gameplay compatibility with HLE or a user-provided BIOS.
- Save-state UI, memory-card management, pause/resume, disk switching, rumble, shaders, enhanced-resolution presets and core-options editing.
