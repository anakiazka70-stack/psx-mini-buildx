package com.psxmini.app.player

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.psxmini.app.emulator.NativeBridge
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.max

/** First native gameplay shell. Uses a software-frame Libretro video callback path. */
class PlayerActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var status: TextView
    private lateinit var surfaceView: SurfaceView
    private var audioTrack: AudioTrack? = null
    private var emulationThread: Thread? = null
    private val running = AtomicBoolean(false)
    private var inputMask: Int = 0
    private val audioBuffer = ShortArray(4096)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 13, 25)
        window.navigationBarColor = Color.rgb(8, 13, 25)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildPlayerUi()
        surfaceView.holder.addCallback(this)
        startEmulation()
    }

    private fun buildPlayerUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 13, 25))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        status = TextView(this).apply {
            text = "Preparing PSX core…"
            setTextColor(Color.rgb(185, 204, 232))
            textSize = 12f
            setPadding(dp(4), dp(5), dp(4), dp(8))
        }
        root.addView(status)

        surfaceView = SurfaceView(this).apply {
            setBackgroundColor(Color.BLACK)
            holder.setFormat(android.graphics.PixelFormat.RGB_565)
        }
        root.addView(surfaceView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { bottomMargin = dp(10) })

        root.addView(buildControlRow(listOf(
            "↑" to 4, "←" to 6, "↓" to 5, "→" to 7,
            "SELECT" to 2, "START" to 3
        )))
        root.addView(buildControlRow(listOf(
            "□" to 9, "△" to 1, "×" to 8, "○" to 0, "L" to 10, "R" to 11
        )))
        val exit = TextView(this).apply {
            text = "STOP GAME"
            gravity = Gravity.CENTER
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(255, 215, 215))
            setPadding(dp(12), dp(11), dp(12), dp(11))
            setOnClickListener { finish() }
        }
        root.addView(exit)
        setContentView(root)
    }

    private fun buildControlRow(items: List<Pair<String, Int>>): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, dp(3))
            items.forEach { (label, id) ->
                val key = TextView(this@PlayerActivity).apply {
                    text = label
                    gravity = Gravity.CENTER
                    textSize = if (label.length > 1) 10f else 18f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    setBackgroundColor(Color.rgb(35, 49, 74))
                    setPadding(dp(10), dp(12), dp(10), dp(12))
                    isClickable = true
                    setOnTouchListener { _, event ->
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> setButton(id, true)
                            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> setButton(id, false)
                        }
                        true
                    }
                }
                addView(key, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    marginStart = dp(3); marginEnd = dp(3)
                })
            }
        }

    private fun setButton(id: Int, pressed: Boolean) {
        val bit = 1 shl id
        inputMask = if (pressed) inputMask or bit else inputMask and bit.inv()
        if (NativeBridge.isLoaded) NativeBridge.nativeSetInputMask(inputMask)
    }

    private fun startEmulation() {
        if (!NativeBridge.isLoaded) {
            showStatus("Native library unavailable: ${NativeBridge.loadError ?: "unknown error"}")
            return
        }
        val gamePath = intent.getStringExtra(EXTRA_GAME_PATH)
        if (gamePath.isNullOrBlank() || !File(gamePath).isFile) {
            showStatus("Game file not found. Return to the library and import it again.")
            return
        }
        val core = File(applicationInfo.nativeLibraryDir, CORE_LIBRARY_NAME)
        if (!core.isFile) {
            showStatus("PCSX ReARMed core is not packaged in this APK. Run the Android APK workflow with core build enabled.")
            return
        }

        NativeBridge.nativeSetInputMask(0)
        running.set(true)
        emulationThread = thread(name = "PSX-Mini-Emulation", isDaemon = true) {
            try {
                val systemDir = File(filesDir, "system").apply { mkdirs() }
                val saveDir = File(filesDir, "saves").apply { mkdirs() }
                val coreStatus = NativeBridge.nativeLoadCore(core.absolutePath, systemDir.absolutePath, saveDir.absolutePath)
                if (!coreStatus.startsWith("CORE_READY")) {
                    showStatus(coreStatus)
                    return@thread
                }
                val gameStatus = NativeBridge.nativeLoadGame(gamePath)
                if (!gameStatus.startsWith("GAME_LOADED")) {
                    showStatus(gameStatus)
                    NativeBridge.nativeShutdown()
                    return@thread
                }

                val sampleRate = NativeBridge.nativeSampleRate().toInt().coerceIn(8000, 96000)
                val minBytes = AudioTrack.getMinBufferSize(
                    sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(4096)
                val track = AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    max(minBytes * 2, 16384),
                    AudioTrack.MODE_STREAM
                )
                audioTrack = track
                track.play()
                showStatus("GAME RUNNING · ${File(gamePath).name}\n${"%.2f".format(NativeBridge.nativeFrameRate())} FPS target · HLE BIOS may be used if no BIOS is imported; compatibility can vary")

                val fps = NativeBridge.nativeFrameRate().takeIf { it in 20.0..240.0 } ?: 60.0
                val frameNanos = (1_000_000_000.0 / fps).toLong()
                while (running.get() && !isFinishing) {
                    val frameStart = System.nanoTime()
                    NativeBridge.nativeRunFrame()
                    val sampleCount = NativeBridge.nativePullAudio(audioBuffer)
                    if (sampleCount > 0) track.write(audioBuffer, 0, sampleCount)
                    val remaining = frameNanos - (System.nanoTime() - frameStart)
                    if (remaining > 0) {
                        try { Thread.sleep(remaining / 1_000_000L, (remaining % 1_000_000L).toInt()) }
                        catch (_: InterruptedException) { break }
                    }
                }
            } catch (error: Throwable) {
                showStatus("Emulation stopped: ${error.message ?: error.javaClass.simpleName}")
            } finally {
                running.set(false)
                runCatching { NativeBridge.nativeUnloadGame() }
                runCatching { NativeBridge.nativeShutdown() }
                runOnUiThread {
                    audioTrack?.let { track -> runCatching { track.pause(); track.flush(); track.release() } }
                    audioTrack = null
                }
            }
        }
    }

    private fun showStatus(message: String) {
        runOnUiThread { if (::status.isInitialized) status.text = message }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        if (NativeBridge.isLoaded) NativeBridge.nativeSetSurface(holder.surface)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (NativeBridge.isLoaded) NativeBridge.nativeSetSurface(holder.surface)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        if (NativeBridge.isLoaded) NativeBridge.nativeSetSurface(null)
    }

    override fun onDestroy() {
        running.set(false)
        emulationThread?.interrupt()
        emulationThread?.join(350)
        if (NativeBridge.isLoaded && emulationThread?.isAlive != true) {
            runCatching { NativeBridge.nativeSetSurface(null) }
        }
        if (NativeBridge.isLoaded) runCatching { NativeBridge.nativeSetInputMask(0) }
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_GAME_PATH = "com.psxmini.app.player.GAME_PATH"
        const val CORE_LIBRARY_NAME = "libpcsx_rearmed_libretro.so"
    }
}
