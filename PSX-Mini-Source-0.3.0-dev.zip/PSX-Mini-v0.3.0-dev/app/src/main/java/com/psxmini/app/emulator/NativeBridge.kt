package com.psxmini.app.emulator

import android.view.Surface

/** JNI entry point for PSX Mini's Android Libretro frontend. */
object NativeBridge {
    val isLoaded: Boolean
    val loadError: String?

    init {
        val result = runCatching { System.loadLibrary("psxmini_native") }
        isLoaded = result.isSuccess
        loadError = result.exceptionOrNull()?.message
    }

    external fun nativeBuildInfo(): String
    external fun nativeCoreStatus(): String
    external fun nativeProbeCore(corePath: String): String
    external fun nativeLoadCore(corePath: String, systemDir: String, saveDir: String): String
    external fun nativeLoadGame(contentPath: String): String
    external fun nativeRunFrame()
    external fun nativeUnloadGame()
    external fun nativeShutdown()
    external fun nativeSetInputMask(mask: Int)
    external fun nativePullAudio(output: ShortArray): Int
    external fun nativeFrameRate(): Double
    external fun nativeSampleRate(): Double
    external fun nativeIsGameLoaded(): Boolean
    external fun nativeSetSurface(surface: Surface?)

    fun buildInfoOrMessage(): String = if (isLoaded) {
        runCatching { nativeBuildInfo() }.getOrElse { "Native bridge call failed: ${it.message}" }
    } else {
        "Native bridge unavailable${loadError?.let { ": $it" }.orEmpty()}"
    }

    fun coreStatusOrMessage(): String = if (isLoaded) {
        runCatching { nativeCoreStatus() }.getOrElse { "Core status unavailable: ${it.message}" }
    } else {
        "Native bridge is not loaded; no emulator core is available."
    }

    fun probeCoreOrMessage(corePath: String): String = if (isLoaded) {
        runCatching { nativeProbeCore(corePath) }
            .getOrElse { "CORE_PROBE_ERROR: ${it.message ?: "unknown native error"}" }
    } else {
        "CORE_PROBE_ERROR: native bridge is unavailable${loadError?.let { ": $it" }.orEmpty()}"
    }
}
