#include "libretro_api_subset.h"

#include <cstdint>

namespace {
retro_environment_t environ_cb = nullptr;
retro_video_refresh_t video_cb = nullptr;
retro_audio_sample_t audio_cb = nullptr;
retro_audio_sample_batch_t audio_batch_cb = nullptr;
retro_input_poll_t input_poll_cb = nullptr;
retro_input_state_t input_state_cb = nullptr;
uint16_t framebuffer[4] = {0xF800, 0x07E0, 0x001F, 0xFFFF};
unsigned selected_port = 999;
unsigned selected_device = RETRO_DEVICE_NONE;
const int16_t audio_samples[4] = {100, -100, 200, -200};
}

extern "C" unsigned retro_api_version() { return RETRO_API_VERSION; }
extern "C" void retro_set_environment(retro_environment_t callback) { environ_cb = callback; }
extern "C" void retro_set_video_refresh(retro_video_refresh_t callback) { video_cb = callback; }
extern "C" void retro_set_audio_sample(retro_audio_sample_t callback) { audio_cb = callback; }
extern "C" void retro_set_audio_sample_batch(retro_audio_sample_batch_t callback) { audio_batch_cb = callback; }
extern "C" void retro_set_input_poll(retro_input_poll_t callback) { input_poll_cb = callback; }
extern "C" void retro_set_input_state(retro_input_state_t callback) { input_state_cb = callback; }
extern "C" void retro_init() {
    if (environ_cb) {
        int format = RETRO_PIXEL_FORMAT_RGB565;
        environ_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT, &format);
        retro_variable variables[] = {{"fake_option", "Fake option; enabled|disabled"}, {nullptr, nullptr}};
        environ_cb(RETRO_ENVIRONMENT_SET_VARIABLES, variables);
        const char *system = nullptr;
        environ_cb(RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY, &system);
    }
}
extern "C" void retro_deinit() {}
extern "C" void retro_get_system_info(retro_system_info *info) {
    info->library_name = "PSX Mini Test Game Core";
    info->library_version = "1.0";
    info->valid_extensions = "cue|bin|chd";
    info->need_fullpath = true;
    info->block_extract = false;
}
extern "C" void retro_get_system_av_info(retro_system_av_info *info) {
    info->geometry = {2, 2, 2, 2, 1.0f};
    info->timing = {60.0, 44100.0};
}
extern "C" bool retro_load_game(const retro_game_info *game) {
    return game && game->path && game->data == nullptr && game->size == 0;
}
extern "C" void retro_unload_game() {}
extern "C" void retro_run() {
    if (input_poll_cb) input_poll_cb();
    const bool up = input_state_cb && input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_UP) != 0;
    framebuffer[0] = up ? 0xFFFF : 0xF800;
    if (video_cb) {
        video_cb(framebuffer, 2, 2, 4);
        // An undersized pitch must be rejected without replacing the last frame.
        video_cb(framebuffer, 2, 2, 2);
    }
    if (audio_batch_cb) audio_batch_cb(audio_samples, 2);
    else if (audio_cb) {
        audio_cb(audio_samples[0], audio_samples[1]);
        audio_cb(audio_samples[2], audio_samples[3]);
    }
}
extern "C" void retro_set_controller_port_device(unsigned port, unsigned device) {
    selected_port = port;
    selected_device = device;
}
extern "C" unsigned fake_selected_port() { return selected_port; }
extern "C" unsigned fake_selected_device() { return selected_device; }
extern "C" void retro_reset() {}
