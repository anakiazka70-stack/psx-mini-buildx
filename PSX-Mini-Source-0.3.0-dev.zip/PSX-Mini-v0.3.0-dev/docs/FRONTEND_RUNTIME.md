# Libretro frontend runtime

## Threading model

The Android `PlayerActivity` owns one emulation worker thread. That thread performs core loading, game loading, repeated `retro_run()` calls, audio queue draining, and orderly core unload/deinitialization. UI control events update a compact joypad bitmask through JNI. Surface creation/destruction updates the native window under a mutex.

The first implementation is intentionally software-rendered. The core emits a software frame through `retro_video_refresh_t`; the JNI bridge copies it into a reusable per-emulation-thread buffer, then converts it into an `ANativeWindow` RGB565 buffer while preserving the core aspect ratio with letterboxing. The callback rejects invalid/oversized frames and undersized pitch values. This keeps the initial path independent of a hardware-rendering context negotiation.

Audio is delivered through the Libretro batch callback into a bounded native queue. The Kotlin worker drains the queue into Android `AudioTrack` as interleaved stereo signed 16-bit PCM.

## Supported environment behavior

- `GET_CAN_DUPE`: true; the frontend retains the most recent frame.
- `GET_SYSTEM_DIRECTORY`: app-private `files/system` folder.
- `GET_SAVE_DIRECTORY`: app-private `files/saves` folder.
- `SET_PIXEL_FORMAT`: 0RGB1555, XRGB8888 and RGB565.
- `SET_VARIABLES` / `GET_VARIABLE`: stores legacy core-option defaults.
- `GET_CORE_OPTIONS_VERSION`: reports version 0 to request legacy variable definitions.
- `GET_LOG_INTERFACE`: forwards core log messages to stderr in native builds.
- `GET_INPUT_BITMASKS`: true; joypad bitmask and individual button queries are supported.
- `retro_set_controller_port_device`: player 1 is set to the standard digital joypad when the core exports this function.
- `SET_GEOMETRY` / `SET_SYSTEM_AV_INFO`: updates aspect ratio and timing hints.

Unimplemented advanced environment interfaces (VFS, hardware rendering, disk-control extensions, rumble, achievements, netplay and core-options v1/v2 editing) return false and are not advertised as supported.

## Known limitations and next work

1. The frontend does not yet implement a user-facing core options page or persist option overrides; only defaults are retained.
2. Audio uses a simple bounded queue and blocking `AudioTrack` writes; underrun/latency tuning needs real-device measurement.
3. Video uses nearest-neighbor scaling into RGB565. Filtering, shaders and enhanced internal resolution are future features and depend on core support.
4. Save states, memory-card management UI, pause/resume, disk swapping and fast-forward are not implemented yet.
5. The actual PCSX ReARMed core must still be built with the pinned Android NDK recipe and tested on device, especially the HLE BIOS path and CUE/BIN loading.
