#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

MACHINE="$(uname -m)"
case "$MACHINE" in
  x86_64) HOST_ABI="x86_64" ;;
  aarch64|arm64) HOST_ABI="arm64-v8a" ;;
  i386|i686) HOST_ABI="x86" ;;
  armv7l|armv8l) HOST_ABI="armeabi-v7a" ;;
  *) echo "Unsupported host architecture for verifier test: $MACHINE" >&2; exit 2 ;;
esac

c++ -std=c++17 -Wall -Wextra -Wpedantic -fPIC -shared \
  -I"$ROOT/app/src/main/cpp/include" \
  "$ROOT/scripts/testdata/fake_libretro_game_core.cpp" \
  -o "$TEMP_DIR/libfake_complete_core.so"
"$ROOT/scripts/verify_core_binary.sh" "$TEMP_DIR/libfake_complete_core.so" "$HOST_ABI"

cat > "$TEMP_DIR/incomplete_core.cpp" <<'CPP'
extern "C" unsigned retro_api_version() { return 1; }
CPP
c++ -std=c++17 -fPIC -shared "$TEMP_DIR/incomplete_core.cpp" -o "$TEMP_DIR/libfake_incomplete_core.so"
if "$ROOT/scripts/verify_core_binary.sh" "$TEMP_DIR/libfake_incomplete_core.so" "$HOST_ABI"; then
  echo "Verifier accepted a core with missing Libretro exports." >&2
  exit 1
fi

WRONG_ABI="arm64-v8a"
if [[ "$HOST_ABI" == "arm64-v8a" ]]; then WRONG_ABI="x86_64"; fi
if "$ROOT/scripts/verify_core_binary.sh" "$TEMP_DIR/libfake_complete_core.so" "$WRONG_ABI"; then
  echo "Verifier accepted a core with the wrong ABI." >&2
  exit 1
fi

echo "Core binary verifier tests: PASS"
