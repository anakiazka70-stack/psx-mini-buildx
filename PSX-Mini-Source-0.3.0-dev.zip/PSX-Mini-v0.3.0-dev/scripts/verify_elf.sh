#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 2 || $# -gt 3 ]]; then
  echo "Usage: $0 <shared-library> <expected-abi> [android-ndk-root]" >&2
  exit 2
fi
BINARY="$1"
ABI="$2"
NDK_ROOT="${3:-${ANDROID_NDK_HOME:-}}"
if [[ ! -s "$BINARY" ]]; then
  echo "ELF_VERIFY_FAILED: file does not exist or is empty: $BINARY" >&2
  exit 1
fi
READELF=""
if [[ -n "$NDK_ROOT" ]]; then
  HOST_TAG=""
  case "$(uname -s)-$(uname -m)" in
    Linux-x86_64) HOST_TAG="linux-x86_64" ;;
    Darwin-arm64|Darwin-x86_64) HOST_TAG="darwin-x86_64" ;;
  esac
  CANDIDATE="$NDK_ROOT/toolchains/llvm/prebuilt/$HOST_TAG/bin/llvm-readelf"
  if [[ -n "$HOST_TAG" && -x "$CANDIDATE" ]]; then READELF="$CANDIDATE"; fi
fi
if [[ -z "$READELF" ]]; then READELF="$(command -v llvm-readelf || command -v readelf || true)"; fi
if [[ -z "$READELF" ]]; then
  echo "ELF_VERIFY_FAILED: llvm-readelf or readelf is required." >&2
  exit 2
fi
HEADER="$($READELF -h "$BINARY")"
MACHINE="$(printf '%s\n' "$HEADER" | sed -n 's/^[[:space:]]*Machine:[[:space:]]*//p' | head -n1)"
case "$ABI" in
  arm64-v8a) EXPECTED='AArch64' ;;
  armeabi-v7a) EXPECTED='ARM' ;;
  x86_64) EXPECTED='X86-64|x86-64' ;;
  x86) EXPECTED='80386|Intel' ;;
  *) echo "ELF_VERIFY_FAILED: unsupported ABI '$ABI'." >&2; exit 2 ;;
esac
if [[ "$ABI" == "x86_64" ]]; then
  [[ "$MACHINE" =~ X86-64|x86-64 ]] || { echo "ELF_VERIFY_FAILED: expected x86_64, got '$MACHINE'." >&2; exit 1; }
elif [[ "$ABI" == "x86" ]]; then
  [[ "$MACHINE" =~ 80386|Intel ]] || { echo "ELF_VERIFY_FAILED: expected x86, got '$MACHINE'." >&2; exit 1; }
else
  [[ "$MACHINE" == *"$EXPECTED"* ]] || { echo "ELF_VERIFY_FAILED: expected $ABI, got '$MACHINE'." >&2; exit 1; }
fi

# The Android NDK r27 toolchain used by this project requires explicit ELF
# page alignment flags for 16 KB page-size ARM64 devices. Check every PT_LOAD.
if [[ "$ABI" == "arm64-v8a" ]]; then
  PROGRAM_HEADERS="$($READELF -lW "$BINARY")"
  mapfile -t LOAD_ALIGNMENTS < <(printf '%s\n' "$PROGRAM_HEADERS" | awk '$1 == "LOAD" {print $NF}')
  if [[ ${#LOAD_ALIGNMENTS[@]} -eq 0 ]]; then
    echo "ELF_VERIFY_FAILED: no PT_LOAD segments found." >&2
    exit 1
  fi
  for alignment in "${LOAD_ALIGNMENTS[@]}"; do
    if [[ ! "$alignment" =~ ^0[xX]([0-9a-fA-F]+)$ ]]; then
      echo "ELF_VERIFY_FAILED: could not parse PT_LOAD alignment '$alignment'." >&2
      exit 1
    fi
    value=$((16#${BASH_REMATCH[1]}))
    if (( value < 16384 )); then
      echo "ELF_VERIFY_FAILED: PT_LOAD alignment $alignment is below 16 KB." >&2
      exit 1
    fi
  done
  echo "16 KB PT_LOAD alignment: verified"

  # Android's 16 KB guidance also calls out GNU_RELRO: its end must either
  # land on a 16 KB boundary or consume the remainder of its containing LOAD.
  mapfile -t LOAD_BOUNDS < <(printf '%s\n' "$PROGRAM_HEADERS" | awk '$1 == "LOAD" {print $3, $6}')
  mapfile -t RELRO_BOUNDS < <(printf '%s\n' "$PROGRAM_HEADERS" | awk '$1 == "GNU_RELRO" {print $3, $6}')
  hex_to_decimal() {
    local raw="$1"
    raw="${raw#0x}"
    raw="${raw#0X}"
    printf '%d' "$((16#$raw))"
  }
  for relro_row in "${RELRO_BOUNDS[@]}"; do
    read -r relro_start_hex relro_size_hex <<< "$relro_row"
    relro_start="$(hex_to_decimal "$relro_start_hex")"
    relro_size="$(hex_to_decimal "$relro_size_hex")"
    relro_end=$((relro_start + relro_size))
    if (( relro_end % 16384 == 0 )); then
      continue
    fi

    relro_matches_load_end=false
    for load_row in "${LOAD_BOUNDS[@]}"; do
      read -r load_start_hex load_size_hex <<< "$load_row"
      load_start="$(hex_to_decimal "$load_start_hex")"
      load_size="$(hex_to_decimal "$load_size_hex")"
      load_end=$((load_start + load_size))
      if (( relro_start >= load_start && relro_end == load_end )); then
        relro_matches_load_end=true
        break
      fi
    done
    if [[ "$relro_matches_load_end" != true ]]; then
      printf 'ELF_VERIFY_FAILED: GNU_RELRO end 0x%x is not 16 KB aligned and does not end with its containing LOAD segment.\n' "$relro_end" >&2
      exit 1
    fi
  done
  if [[ ${#RELRO_BOUNDS[@]} -gt 0 ]]; then
    echo "16 KB GNU_RELRO alignment: verified"
  else
    echo "GNU_RELRO: no segment present"
  fi
fi

echo "ELF_VERIFY_OK: $BINARY"
echo "ABI: $ABI ($MACHINE)"
