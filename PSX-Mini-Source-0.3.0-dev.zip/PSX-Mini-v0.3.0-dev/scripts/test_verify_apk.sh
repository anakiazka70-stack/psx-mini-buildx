#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

case "$(uname -m)" in
  x86_64) HOST_ABI=x86_64 ;;
  aarch64|arm64) HOST_ABI=arm64-v8a ;;
  i386|i686) HOST_ABI=x86 ;;
  armv7l|armv8l) HOST_ABI=armeabi-v7a ;;
  *) echo "Unsupported host architecture for APK verifier test." >&2; exit 2 ;;
esac

mkdir -p "$TEMP_DIR/apk/lib/$HOST_ABI" "$TEMP_DIR/bin"
c++ -std=c++17 -fPIC -shared -I"$ROOT/app/src/main/cpp/include" \
  "$ROOT/scripts/testdata/fake_libretro_game_core.cpp" -o "$TEMP_DIR/apk/lib/$HOST_ABI/libpcsx_rearmed_libretro.so"
printf 'extern "C" void frontend_test_symbol() {}\n' > "$TEMP_DIR/frontend.cpp"
c++ -std=c++17 -fPIC -shared "$TEMP_DIR/frontend.cpp" \
  -o "$TEMP_DIR/apk/lib/$HOST_ABI/libpsxmini_native.so"
(
  cd "$TEMP_DIR/apk"
  zip -qr "$TEMP_DIR/test.apk" lib
)
cat > "$TEMP_DIR/bin/zipalign" <<'ZIPALIGN'
#!/usr/bin/env sh
set -eu
[ "$1" = "-c" ]
[ "$2" = "-P" ]
[ "$3" = "16" ]
[ "$4" = "4" ]
[ -s "$5" ]
echo "ZIPALIGN_TEST_STUB: accepted 16 KB verification arguments"
ZIPALIGN
chmod +x "$TEMP_DIR/bin/zipalign"
PATH="$TEMP_DIR/bin:$PATH" "$ROOT/scripts/verify_apk.sh" "$TEMP_DIR/test.apk" "$HOST_ABI"

# Check the negative path when the frontend entry exists but the core is absent.
mkdir -p "$TEMP_DIR/missing/lib/$HOST_ABI"
cp "$TEMP_DIR/apk/lib/$HOST_ABI/libpsxmini_native.so" "$TEMP_DIR/missing/lib/$HOST_ABI/"
(
  cd "$TEMP_DIR/missing"
  zip -qr "$TEMP_DIR/missing-core.apk" lib
)
if PATH="$TEMP_DIR/bin:$PATH" "$ROOT/scripts/verify_apk.sh" "$TEMP_DIR/missing-core.apk" "$HOST_ABI"; then
  echo "APK verifier accepted an APK without the PS1 core." >&2
  exit 1
fi

echo "APK verifier packaging test: PASS"
