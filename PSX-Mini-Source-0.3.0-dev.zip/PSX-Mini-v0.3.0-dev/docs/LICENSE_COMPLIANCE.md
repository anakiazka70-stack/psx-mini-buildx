# License compliance checklist

- [ ] Choose and add a root license for PSX Mini frontend code.
- [ ] Pin PCSX ReARMed to an exact commit and preserve GPL-2.0 license text.
- [ ] Include corresponding source and local patches for distributed GPL components as required.
- [ ] Add the exact Libretro API MIT notice when the header is vendored.
- [ ] List all native libraries and their license notices in the APK/source bundle.
- [ ] Keep BIOS, commercial game images, Sony assets, and cover art out of the repository and APK.
- [ ] Review the final combined distribution before publishing.
