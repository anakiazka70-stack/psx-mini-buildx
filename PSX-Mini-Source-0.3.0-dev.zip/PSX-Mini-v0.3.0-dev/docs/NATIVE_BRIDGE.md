# Native bridge — v0.3.0-dev

The app builds `libpsxmini_native.so` with C++17, JNI, and CMake. The bridge now exposes:

- Native build and ABI diagnostics.
- Dynamic PCSX ReARMed core loading and required Libretro export/API checks.
- Game load, single-frame execution, unload and shutdown methods.
- Joypad input mask and audio-buffer retrieval.
- Android `Surface` attachment through `ANativeWindow` for RGB565 presentation.

The bridge and PCSX ReARMed core are currently packaged for `arm64-v8a` only using NDK `27.2.12479018` and CMake `3.22.1`. The Gradle ABI filter is intentionally restricted to the ABI for which the matching core is built.

`scripts/test_native_bridge_host.sh` validates the JNI load/probe path on a host JVM. `scripts/test_libretro_frontend_host.sh` validates the runtime lifecycle and video/audio/input callbacks against a fake core. Android NDK compilation and device verification remain pending.
