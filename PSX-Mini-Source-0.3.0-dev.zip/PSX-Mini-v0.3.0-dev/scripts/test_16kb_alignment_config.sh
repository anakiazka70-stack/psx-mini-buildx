#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PATCH="$ROOT/patches/pcsx-rearmed-16kb-page-alignment.patch"
CMAKE="$ROOT/app/src/main/cpp/CMakeLists.txt"
BUILD_SCRIPT="$ROOT/scripts/build_core_android.sh"

for flag in \
  '-Wl,-z,max-page-size=16384' \
  '-Wl,-z,common-page-size=16384'; do
  grep -Fq -- "$flag" "$CMAKE" || {
    echo "16KB_CONFIG_FAILED: frontend CMake is missing $flag" >&2
    exit 1
  }
done

grep -Fq -- '-Wl,-z,common-page-size=16384' "$PATCH" || {
  echo "16KB_CONFIG_FAILED: core patch is missing common-page-size flag" >&2
  exit 1
}
grep -Fq 'git -C "$WORK_DIR" apply --check "$ROOT/patches/pcsx-rearmed-16kb-page-alignment.patch"' "$BUILD_SCRIPT" || {
  echo "16KB_CONFIG_FAILED: core build script does not check patch applicability" >&2
  exit 1
}
grep -Fq 'verify_core_binary.sh' "$BUILD_SCRIPT" || {
  echo "16KB_CONFIG_FAILED: core build script does not verify the final ELF" >&2
  exit 1
}

TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT
mkdir -p "$TEMP_DIR/jni"
cat > "$TEMP_DIR/jni/Android.mk" <<'MAKEFILE'
LOCAL_LDFLAGS += -Wl,--gc-sections

LOCAL_LDFLAGS += -Wl,-z,max-page-size=16384

LOCAL_LDLIBS := -lz -llog
MAKEFILE
(
  cd "$TEMP_DIR"
  git apply --check "$PATCH"
  git apply "$PATCH"
)
grep -Fq -- '-Wl,-z,common-page-size=16384' "$TEMP_DIR/jni/Android.mk" || {
  echo "16KB_CONFIG_FAILED: patch did not add common-page-size flag" >&2
  exit 1
}

echo "16 KB alignment configuration and upstream patch test: PASS"
