package com.psxmini.app.storage

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.psxmini.app.data.CueValidator
import com.psxmini.app.data.GameRepository
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ContentStager(private val context: Context) {
    data class ImportResult(val folder: File, val copiedFiles: List<File>, val skippedFiles: List<String>)

    fun importGameUris(uris: List<Uri>): ImportResult {
        require(uris.isNotEmpty()) { "No game files were selected." }
        val gamesDir = File(context.filesDir, "games").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val folder = File(gamesDir, "game_$stamp").apply { mkdirs() }
        val copied = mutableListOf<File>()
        val skipped = mutableListOf<String>()
        val names = mutableSetOf<String>()

        try {
            uris.distinctBy { it.toString() }.forEach { uri ->
                val originalName = queryDisplayName(context.contentResolver, uri)
                // Normalize both Unix and Windows separators before keeping only
                // the display name. Providers should return a name, not a path.
                val safeName = File(originalName.replace('\\', '/')).name
                val extension = safeName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                if (extension !in GameRepository.supportedExtensions) {
                    skipped += "$originalName (unsupported extension)"
                    return@forEach
                }
                if (!names.add(safeName.lowercase(Locale.ROOT))) {
                    skipped += "$originalName (duplicate name in selection)"
                    return@forEach
                }
                val destination = File(folder, safeName)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(destination).use { output -> input.copyTo(output, 64 * 1024) }
                    copied += destination
                } ?: run { skipped += "$originalName (could not open)" }
            }
            if (copied.isEmpty()) throw IllegalArgumentException("No supported game files were imported.")
            copied.filter { it.extension.equals("cue", ignoreCase = true) }
                .forEach { CueValidator.flattenTrackReferences(it) }
            return ImportResult(folder, copied, skipped)
        } catch (error: Exception) {
            folder.deleteRecursively()
            throw error
        }
    }

    fun importBiosUri(uri: Uri): File {
        val name = File(queryDisplayName(context.contentResolver, uri)).name
        val extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        require(extension in setOf("bin", "rom", "bios")) { "Choose a BIOS file with .bin, .rom, or .bios extension." }
        val biosDir = File(context.filesDir, "system").apply { mkdirs() }
        val destination = File(biosDir, name)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destination).use { output -> input.copyTo(output, 64 * 1024) }
        } ?: throw IllegalStateException("Could not read the selected BIOS file.")
        return destination
    }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index)?.takeIf { it.isNotBlank() }?.let { return it }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: "disc.bin"
    }
}
