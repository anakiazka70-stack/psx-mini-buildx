#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JAVAC_BIN="$(command -v javac || true)"
if [[ -z "$JAVAC_BIN" ]]; then
  echo "javac is required for this host JNI smoke test." >&2
  exit 2
fi
JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$JAVAC_BIN")")")"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

NATIVE_LIB="$TEMP_DIR/libpsxmini_native_host.so"
FAKE_CORE="$TEMP_DIR/libfake_ps1_core.so"
c++ -std=c++17 -Wall -Wextra -Wpedantic -shared -fPIC \
  "$ROOT/app/src/main/cpp/jni/native_bridge.cpp" \
  "$ROOT/app/src/main/cpp/jni/libretro_frontend.cpp" \
  -I"$ROOT/app/src/main/cpp/include" \
  -I"$JAVA_HOME/include" -I"$JAVA_HOME/include/linux" \
  -ldl -pthread -o "$NATIVE_LIB"
c++ -std=c++17 -Wall -Wextra -Wpedantic -shared -fPIC \
  -I"$ROOT/app/src/main/cpp/include" \
  "$ROOT/scripts/testdata/fake_libretro_game_core.cpp" -o "$FAKE_CORE"

mkdir -p "$TEMP_DIR/src/com/psxmini/app/emulator"
cat > "$TEMP_DIR/src/com/psxmini/app/emulator/NativeBridge.java" <<JAVA
package com.psxmini.app.emulator;
public final class NativeBridge {
    static { System.load("$NATIVE_LIB"); }
    public native String nativeBuildInfo();
    public native String nativeCoreStatus();
    public native String nativeProbeCore(String path);
    public static void main(String[] args) {
        NativeBridge bridge = new NativeBridge();
        String build = bridge.nativeBuildInfo();
        String probe = bridge.nativeProbeCore("$FAKE_CORE");
        System.out.println(build);
        System.out.println(probe);
        if (!build.contains("PSX Mini native frontend 0.3.0-dev")) {
            throw new AssertionError("JNI build info failed: " + build);
        }
        if (!probe.contains("CORE_READY") || !probe.contains("PSX Mini Test Game Core") || !probe.contains("cue|bin|chd")) {
            throw new AssertionError("JNI native core probe failed: " + probe);
        }
        String missing = bridge.nativeProbeCore("$TEMP_DIR/does-not-exist.so");
        if (!missing.startsWith("CORE_NOT_FOUND:")) {
            throw new AssertionError("Missing-core error path failed: " + missing);
        }
    }
}
JAVA
javac -d "$TEMP_DIR/classes" "$TEMP_DIR/src/com/psxmini/app/emulator/NativeBridge.java"
java -cp "$TEMP_DIR/classes" com.psxmini.app.emulator.NativeBridge
