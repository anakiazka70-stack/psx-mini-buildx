package com.psxmini.app.storage

import android.content.Intent

/** Builds Android's system document picker intents. No broad storage permission is needed. */
object SafDocumentPicker {
    fun gameFiles(): Intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
        addCategory(Intent.CATEGORY_OPENABLE)
        type = "*/*"
        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        // Files are copied immediately into app-private storage, so a temporary
        // read grant is sufficient; no persisted URI permission is needed.
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    fun biosFile(): Intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
        addCategory(Intent.CATEGORY_OPENABLE)
        type = "*/*"
        // Files are copied immediately into app-private storage, so a temporary
        // read grant is sufficient; no persisted URI permission is needed.
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}
