#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

c++ -std=c++17 -Wall -Wextra -Wpedantic \
  -I"$ROOT/app/src/main/cpp/include" \
  "$ROOT/app/src/main/cpp/jni/libretro_frontend.cpp" \
  "$ROOT/scripts/testdata/test_libretro_frontend_host.cpp" \
  -ldl -pthread -o "$TEMP_DIR/test_frontend"

c++ -std=c++17 -Wall -Wextra -Wpedantic -fPIC -shared \
  -I"$ROOT/app/src/main/cpp/include" \
  "$ROOT/scripts/testdata/fake_libretro_game_core.cpp" \
  -o "$TEMP_DIR/libfake_ps1_core.so"

printf 'fake game image' > "$TEMP_DIR/fake-game.cue"
"$TEMP_DIR/test_frontend" "$TEMP_DIR/libfake_ps1_core.so" "$TEMP_DIR/fake-game.cue"
