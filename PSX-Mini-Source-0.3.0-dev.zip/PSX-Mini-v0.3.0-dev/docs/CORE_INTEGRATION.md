# PCSX ReARMed core integration status

## Pinned upstream dependency

- Repository: https://github.com/libretro/pcsx_rearmed
- Full commit: `ff81ed17a15241d2f3730cdd7585b38e172532ca`
- License: GPL-2.0
- Android build path: upstream `jni/Android.mk` and `jni/Application.mk`
- Initial packaged ABI: `arm64-v8a`

The pin is a selected reproducible revision, not a claim that it is the newest upstream revision.

## Frontend runtime implemented through v0.3.0-dev

PSX Mini now implements the essential Libretro lifecycle and callback path in `jni/libretro_frontend.cpp`:

- Dynamically loads the packaged core and resolves the required `retro_*` exports.
- Checks Libretro API version 1.
- Registers environment, video, audio-sample, audio-batch, input-poll and input-state callbacks.
- Provides app-private system and save directories to the core.
- Supports the legacy core-options API (version 0) and keeps the declared default option values.
- Negotiates 0RGB1555, XRGB8888 or RGB565 software video output.
- Loads game files by full path when requested by the core, or retains content bytes for cores that request in-memory content.
- Executes `retro_run()` through a controlled frame loop.
- Buffers audio samples for Android `AudioTrack` and copies software video frames to an Android `Surface` through `ANativeWindow`.
- Maps on-screen controls to the standard Libretro joypad IDs and selects a digital joypad for player 1 when the core exports `retro_set_controller_port_device`.

The Android UI now adds a Play action for imported entries and a landscape player screen with a software SurfaceView and touch controls.

## What is still unverified

The frontend is tested against a purpose-built fake Libretro shared library. That verifies the callback sequence and data path at the host level, but it is not a substitute for the real PCSX ReARMed core. The actual upstream core build, Android NDK link, APK assembly, Android Surface rendering, audio timing, and Pepsi Man compatibility still need to be tested in GitHub Actions and on an Android device. The v0.3.0-dev workflow now rejects a core with the wrong ELF architecture or missing required Libretro exports, then checks that both native libraries are packaged in the final APK.

## BIOS and content

PCSX ReARMed uses the frontend system directory for BIOS lookup and the save directory for memory-card/save data. PSX Mini's optional BIOS importer copies user-selected BIOS files into its app-private `files/system/` directory. No BIOS image or game content is included. If a compatible BIOS is absent, PCSX ReARMed can fall back to HLE, but the core documentation warns that HLE has reduced compatibility.

PCSX ReARMed documentation lists `.cue`, `.bin`, `.chd`, `.pbp`, `.iso` and other supported extensions. A CUE sheet should be imported together with every track file it references; the app validates missing relative track files before offering Play.

## ABI policy

The current workflow packages the core for `arm64-v8a`. The app and bundled PCSX ReARMed core are currently built for `arm64-v8a` only. The Gradle ABI filter excludes all other ABIs so the app cannot install a frontend-only variant without a matching PS1 core. Add more ABIs only after the core and frontend libraries for each ABI are built and verified together.


## v0.3.0-dev packaging gates

- `scripts/verify_core_binary.sh` checks that the built `.so` is a shared ELF for the requested ABI and exports the Libretro functions required by the frontend.
- `scripts/verify_apk.sh` checks that the final APK contains both `libpsxmini_native.so` and `libpcsx_rearmed_libretro.so` under `lib/arm64-v8a/`, then repeats the core verification against the extracted library.
- `scripts/test_core_binary_verifier.sh` uses a complete fake core, a deliberately incomplete fake core, and a deliberately wrong ABI expectation to test both pass and reject paths.
- The app is built for `arm64-v8a` only until other ABIs have matching core builds.


## Android 16 KB page-size compatibility

The project uses Android NDK r27.2.12479018, so both the native frontend and the upstream core need explicit ELF alignment flags. The APK uses uncompressed native-library packaging (AGP 8.13.2) and the CI verifier checks 16 KB ZIP entry alignment with `zipalign -c -P 16 4`. The PSX Mini CMake target links with `-Wl,-z,max-page-size=16384` and `-Wl,-z,common-page-size=16384`. The pinned upstream `jni/Android.mk` already sets the maximum page size; `patches/pcsx-rearmed-16kb-page-alignment.patch` adds the matching common page-size flag during the reproducible core build. The core and APK verification scripts reject ARM64 native libraries whose `PT_LOAD` alignment is below 16 KB and validate the `GNU_RELRO` boundary using Android’s 16 KB compatibility criteria.
