# Storage and import design

The app requests documents through `Intent.ACTION_OPEN_DOCUMENT` with `CATEGORY_OPENABLE` and `EXTRA_ALLOW_MULTIPLE`. It does not request `READ_EXTERNAL_STORAGE`, `READ_MEDIA_*`, or `MANAGE_EXTERNAL_STORAGE`.

Selected files are streamed into app-private storage under `files/games/<game-folder>/`. The app therefore does not need to retain broad storage access after import. Multi-file BIN/CUE imports are grouped into a single folder; directory-qualified CUE `FILE` paths are rewritten to the imported basenames. Track names are matched case-insensitively and rewritten to the exact on-disk spelling before the parser checks every reference against copied files.

BIOS import is a separate picker action and writes to `files/system/`. This starter only copies the selected file; it does not identify, hash-check, or validate the firmware.

A standalone BIN remains in the library but is not offered for Play until a matching CUE sheet and all referenced tracks are imported. PCSX ReARMed documentation describes CUE as the required disc layout description for this path.
