#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 1 || $# -gt 3 ]]; then
  echo "Usage: $0 <apk-path> [expected-abi=arm64-v8a] [android-ndk-root]" >&2
  exit 2
fi
APK_PATH="$1"
ABI="${2:-arm64-v8a}"
NDK_ROOT="${3:-${ANDROID_NDK_HOME:-}}"
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ ! -s "$APK_PATH" ]]; then
  echo "APK_VERIFY_FAILED: APK not found or empty: $APK_PATH" >&2
  exit 1
fi
UNZIP="$(command -v unzip || true)"
if [[ -z "$UNZIP" ]]; then
  echo "APK_VERIFY_FAILED: unzip is required." >&2
  exit 2
fi
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

ZIPALIGN=""
if [[ -n "$SDK_ROOT" ]]; then
  CANDIDATE="$SDK_ROOT/build-tools/36.0.0/zipalign"
  if [[ -x "$CANDIDATE" ]]; then ZIPALIGN="$CANDIDATE"; fi
fi
if [[ -z "$ZIPALIGN" ]]; then ZIPALIGN="$(command -v zipalign || true)"; fi
if [[ -z "$ZIPALIGN" ]]; then
  echo "APK_VERIFY_FAILED: zipalign from Android Build Tools 35.0.0+ is required." >&2
  exit 2
fi
"$ZIPALIGN" -c -P 16 4 "$APK_PATH"

CORE_ENTRY="lib/$ABI/libpcsx_rearmed_libretro.so"
FRONTEND_ENTRY="lib/$ABI/libpsxmini_native.so"
if ! "$UNZIP" -Z1 "$APK_PATH" | grep -Fxq "$CORE_ENTRY"; then
  echo "APK_VERIFY_FAILED: missing $CORE_ENTRY" >&2
  exit 1
fi
if ! "$UNZIP" -Z1 "$APK_PATH" | grep -Fxq "$FRONTEND_ENTRY"; then
  echo "APK_VERIFY_FAILED: missing $FRONTEND_ENTRY" >&2
  exit 1
fi
"$UNZIP" -p "$APK_PATH" "$CORE_ENTRY" > "$TEMP_DIR/core.so"
"$UNZIP" -p "$APK_PATH" "$FRONTEND_ENTRY" > "$TEMP_DIR/frontend.so"
if [[ ! -s "$TEMP_DIR/frontend.so" ]]; then
  echo "APK_VERIFY_FAILED: packaged native frontend is empty." >&2
  exit 1
fi
"$(cd "$(dirname "$0")" && pwd)/verify_elf.sh" "$TEMP_DIR/frontend.so" "$ABI" "$NDK_ROOT"
"$(cd "$(dirname "$0")" && pwd)/verify_core_binary.sh" "$TEMP_DIR/core.so" "$ABI" "$NDK_ROOT"
echo "APK_VERIFY_OK: $APK_PATH contains frontend and $ABI PCSX ReARMed core with 16 KB ZIP alignment."
