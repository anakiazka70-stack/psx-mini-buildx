package com.psxmini.app.platform

import android.os.Build

object DeviceInfo {
    fun supportedAbis(): String = Build.SUPPORTED_ABIS.joinToString().ifBlank { "Unknown" }
    fun androidVersion(): String = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
}
