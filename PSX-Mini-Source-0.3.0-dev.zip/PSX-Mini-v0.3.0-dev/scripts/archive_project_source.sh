#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUTPUT="${1:-$ROOT/PSX-Mini-frontend-source.tar.gz}"
mkdir -p "$(dirname "$OUTPUT")"
TEMP_OUTPUT="$(mktemp)"
trap 'rm -f "$TEMP_OUTPUT"' EXIT

# Keep the complete PSX Mini frontend, build scripts, tests, docs and notices.
# Generated APKs, local build trees and the separately archived GPL core are excluded.
tar -czf "$TEMP_OUTPUT" \
  --exclude='.git' \
  --exclude='.gradle' \
  --exclude='.idea' \
  --exclude='.build' \
  --exclude='build' \
  --exclude='*/build' \
  --exclude='app/src/main/jniLibs' \
  --exclude='PSX-Mini-frontend-source.tar.gz' \
  --exclude='PSX-ReARMed-source.tar.gz' \
  --exclude='PSX-ReARMed-*-source.tar.gz' \
  --exclude='*.apk' \
  -C "$ROOT" .

mv "$TEMP_OUTPUT" "$OUTPUT"
echo "PROJECT_SOURCE_ARCHIVE_OK: $OUTPUT"
