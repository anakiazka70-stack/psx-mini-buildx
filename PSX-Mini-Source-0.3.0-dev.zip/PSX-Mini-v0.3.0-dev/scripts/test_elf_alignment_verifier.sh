#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT
mkdir -p "$TEMP_DIR/bin"
printf 'not-an-elf-but-readelf-is-stubbed\n' > "$TEMP_DIR/fake.so"

cat > "$TEMP_DIR/bin/readelf" <<'READELF'
#!/usr/bin/env bash
set -euo pipefail
case "$1" in
  -h)
    printf '  Class:                             ELF64\n  Machine:                           AArch64\n'
    ;;
  -lW)
    case "${FAKE_READELF_MODE:-valid-aligned}" in
      valid-aligned)
        cat <<'HEADERS'
Type           Offset   VirtAddr           PhysAddr           FileSiz  MemSiz   Flg Align
LOAD           0x000000 0x0000000000000000 0x0000000000000000 0x002000 0x002000 R E 0x4000
LOAD           0x004000 0x0000000000004000 0x0000000000004000 0x003000 0x004000 RW  0x4000
GNU_RELRO      0x004000 0x0000000000004000 0x0000000000004000 0x003000 0x004000 R   0x1
HEADERS
        ;;
      valid-load-end)
        cat <<'HEADERS'
Type           Offset   VirtAddr           PhysAddr           FileSiz  MemSiz   Flg Align
LOAD           0x000000 0x0000000000000000 0x0000000000000000 0x002000 0x002000 R E 0x4000
LOAD           0x004000 0x0000000000004000 0x0000000000004000 0x005000 0x005000 RW  0x4000
GNU_RELRO      0x004000 0x0000000000004000 0x0000000000004000 0x005000 0x005000 R   0x1
HEADERS
        ;;
      invalid-relro)
        cat <<'HEADERS'
Type           Offset   VirtAddr           PhysAddr           FileSiz  MemSiz   Flg Align
LOAD           0x000000 0x0000000000000000 0x0000000000000000 0x002000 0x002000 R E 0x4000
LOAD           0x004000 0x0000000000004000 0x0000000000004000 0x006000 0x006000 RW  0x4000
GNU_RELRO      0x004000 0x0000000000004000 0x0000000000004000 0x005000 0x005000 R   0x1
HEADERS
        ;;
      invalid-load-alignment)
        cat <<'HEADERS'
Type           Offset   VirtAddr           PhysAddr           FileSiz  MemSiz   Flg Align
LOAD           0x000000 0x0000000000000000 0x0000000000000000 0x002000 0x002000 R E 0x1000
LOAD           0x004000 0x0000000000004000 0x0000000000004000 0x003000 0x004000 RW  0x4000
GNU_RELRO      0x004000 0x0000000000004000 0x0000000000004000 0x003000 0x004000 R   0x1
HEADERS
        ;;
      *) echo "Unknown test mode" >&2; exit 2 ;;
    esac
    ;;
  *) echo "Unexpected readelf arguments: $*" >&2; exit 2 ;;
esac
READELF
chmod +x "$TEMP_DIR/bin/readelf"

PATH="$TEMP_DIR/bin:$PATH" FAKE_READELF_MODE=valid-aligned \
  "$ROOT/scripts/verify_elf.sh" "$TEMP_DIR/fake.so" arm64-v8a
PATH="$TEMP_DIR/bin:$PATH" FAKE_READELF_MODE=valid-load-end \
  "$ROOT/scripts/verify_elf.sh" "$TEMP_DIR/fake.so" arm64-v8a
if PATH="$TEMP_DIR/bin:$PATH" FAKE_READELF_MODE=invalid-relro \
  "$ROOT/scripts/verify_elf.sh" "$TEMP_DIR/fake.so" arm64-v8a; then
  echo "ELF verifier accepted an invalid GNU_RELRO boundary." >&2
  exit 1
fi
if PATH="$TEMP_DIR/bin:$PATH" FAKE_READELF_MODE=invalid-load-alignment \
  "$ROOT/scripts/verify_elf.sh" "$TEMP_DIR/fake.so" arm64-v8a; then
  echo "ELF verifier accepted a PT_LOAD alignment below 16 KB." >&2
  exit 1
fi

echo "ELF 16 KB alignment verifier tests: PASS"
