#include <jni.h>

#include "libretro_frontend.h"

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

#ifdef __ANDROID__
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <android/log.h>
#include <mutex>
#endif

namespace {
const char *current_abi() {
#if defined(__aarch64__)
    return "arm64-v8a";
#elif defined(__arm__)
    return "armeabi-v7a";
#elif defined(__x86_64__)
    return "x86_64";
#elif defined(__i386__)
    return "x86";
#else
    return "unknown";
#endif
}

jstring to_java(JNIEnv *env, const char *value) {
    return env->NewStringUTF(value ? value : "");
}

std::string from_java(JNIEnv *env, jstring value) {
    if (!value) return {};
    const char *chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

#ifdef __ANDROID__
std::mutex g_window_mutex;
ANativeWindow *g_window = nullptr;

uint16_t to_rgb565(const uint8_t *row, unsigned x, int format) {
    if (format == 2) {
        uint16_t value;
        std::memcpy(&value, row + static_cast<size_t>(x) * 2U, sizeof(value));
        return value;
    }
    if (format == 0) {
        uint16_t value;
        std::memcpy(&value, row + static_cast<size_t>(x) * 2U, sizeof(value));
        const unsigned r = (value >> 10U) & 0x1fU;
        const unsigned g = (value >> 5U) & 0x1fU;
        const unsigned b = value & 0x1fU;
        return static_cast<uint16_t>((r << 11U) | ((g << 1U) | (g >> 4U)) << 5U | b);
    }
    uint32_t value;
    std::memcpy(&value, row + static_cast<size_t>(x) * 4U, sizeof(value));
    const unsigned r = (value >> 16U) & 0xffU;
    const unsigned g = (value >> 8U) & 0xffU;
    const unsigned b = value & 0xffU;
    return static_cast<uint16_t>(((r >> 3U) << 11U) | ((g >> 2U) << 5U) | (b >> 3U));
}

void render_latest_frame() {
    std::lock_guard<std::mutex> lock(g_window_mutex);
    if (!g_window) return;

    PsxMiniVideoInfo info{};
    if (!psxmini_get_video_info(&info)) return;
    const size_t required = psxmini_copy_video_frame(nullptr, 0);
    if (required == 0 || required > 32U * 1024U * 1024U) return;
    // Reuse the per-emulation-thread buffer to avoid a heap allocation every frame.
    thread_local std::vector<uint8_t> frame;
    frame.resize(required);
    if (psxmini_copy_video_frame(frame.data(), frame.size()) != required) return;

    ANativeWindow_Buffer buffer{};
    if (ANativeWindow_lock(g_window, &buffer, nullptr) != 0) return;
    if (buffer.bits == nullptr || buffer.width <= 0 || buffer.height <= 0 || buffer.format != WINDOW_FORMAT_RGB_565) {
        ANativeWindow_unlockAndPost(g_window);
        return;
    }

    auto *destination = static_cast<uint16_t *>(buffer.bits);
    for (int y = 0; y < buffer.height; ++y) {
        std::fill(destination + static_cast<size_t>(y) * static_cast<size_t>(buffer.stride),
                  destination + static_cast<size_t>(y) * static_cast<size_t>(buffer.stride) + static_cast<size_t>(buffer.width),
                  static_cast<uint16_t>(0));
    }

    const float aspect = info.aspect_ratio > 0.1f ? info.aspect_ratio :
        static_cast<float>(info.width) / static_cast<float>(info.height);
    int draw_width = buffer.width;
    int draw_height = static_cast<int>(static_cast<float>(draw_width) / aspect);
    if (draw_height > buffer.height) {
        draw_height = buffer.height;
        draw_width = static_cast<int>(static_cast<float>(draw_height) * aspect);
    }
    draw_width = std::max(1, std::min(draw_width, buffer.width));
    draw_height = std::max(1, std::min(draw_height, buffer.height));
    const int offset_x = (buffer.width - draw_width) / 2;
    const int offset_y = (buffer.height - draw_height) / 2;
    for (int y = 0; y < draw_height; ++y) {
        const unsigned source_y = std::min(info.height - 1U,
            static_cast<unsigned>((static_cast<uint64_t>(y) * info.height) / static_cast<unsigned>(draw_height)));
        const uint8_t *source_row = frame.data() + static_cast<size_t>(source_y) * info.pitch;
        uint16_t *target_row = destination + static_cast<size_t>(offset_y + y) * static_cast<size_t>(buffer.stride) + static_cast<size_t>(offset_x);
        for (int x = 0; x < draw_width; ++x) {
            const unsigned source_x = std::min(info.width - 1U,
                static_cast<unsigned>((static_cast<uint64_t>(x) * info.width) / static_cast<unsigned>(draw_width)));
            target_row[x] = to_rgb565(source_row, source_x, info.pixel_format);
        }
    }
    ANativeWindow_unlockAndPost(g_window);
}
#endif
} // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeBuildInfo(JNIEnv *env, jobject /* instance */) {
    const std::string info = std::string("PSX Mini native frontend 0.3.0-dev | ABI: ") + current_abi();
    return to_java(env, info.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeCoreStatus(JNIEnv *env, jobject /* instance */) {
    return to_java(env, psxmini_get_runtime_status());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeProbeCore(JNIEnv *env, jobject /* instance */, jstring core_path) {
    const std::string path = from_java(env, core_path);
    if (path.empty()) return to_java(env, "CORE_NOT_FOUND: no core path was supplied.");
    // A full lifecycle load is used for the probe so that callback registration is checked too.
    const char *result = psxmini_load_core(path.c_str(), "", "");
    std::string message = result ? result : "CORE_PROBE_ERROR: no status was returned.";
    psxmini_shutdown();
    return to_java(env, message.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeLoadCore(JNIEnv *env, jobject /* instance */,
                                                           jstring core_path, jstring system_dir, jstring save_dir) {
    const std::string core = from_java(env, core_path);
    const std::string system = from_java(env, system_dir);
    const std::string save = from_java(env, save_dir);
    return to_java(env, psxmini_load_core(core.c_str(), system.c_str(), save.c_str()));
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeLoadGame(JNIEnv *env, jobject /* instance */, jstring content_path) {
    const std::string content = from_java(env, content_path);
    return to_java(env, psxmini_load_game(content.c_str()));
}

extern "C" JNIEXPORT void JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeRunFrame(JNIEnv *, jobject /* instance */) {
    psxmini_run_frame();
#ifdef __ANDROID__
    render_latest_frame();
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeUnloadGame(JNIEnv *, jobject /* instance */) {
    psxmini_unload_game();
}

extern "C" JNIEXPORT void JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeShutdown(JNIEnv *, jobject /* instance */) {
    psxmini_shutdown();
}

extern "C" JNIEXPORT void JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeSetInputMask(JNIEnv *, jobject /* instance */, jint mask) {
    psxmini_set_input_mask(static_cast<uint16_t>(mask & 0xffff));
}

extern "C" JNIEXPORT jint JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativePullAudio(JNIEnv *env, jobject /* instance */, jshortArray output) {
    if (!output) return 0;
    const jsize capacity = env->GetArrayLength(output);
    if (capacity <= 0) return 0;
    jshort *samples = env->GetShortArrayElements(output, nullptr);
    if (!samples) return 0;
    const size_t count = psxmini_pull_audio(reinterpret_cast<int16_t *>(samples), static_cast<size_t>(capacity));
    env->ReleaseShortArrayElements(output, samples, count > 0 ? 0 : JNI_ABORT);
    return static_cast<jint>(count);
}

extern "C" JNIEXPORT jdouble JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeFrameRate(JNIEnv *, jobject /* instance */) {
    return psxmini_get_frame_rate();
}

extern "C" JNIEXPORT jdouble JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeSampleRate(JNIEnv *, jobject /* instance */) {
    return psxmini_get_sample_rate();
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeIsGameLoaded(JNIEnv *, jobject /* instance */) {
    return psxmini_is_game_loaded() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_psxmini_app_emulator_NativeBridge_nativeSetSurface(JNIEnv *env, jobject /* instance */, jobject surface) {
#ifdef __ANDROID__
    ANativeWindow *next = surface ? ANativeWindow_fromSurface(env, surface) : nullptr;
    std::lock_guard<std::mutex> lock(g_window_mutex);
    if (g_window) ANativeWindow_release(g_window);
    g_window = next;
    if (g_window) ANativeWindow_setBuffersGeometry(g_window, 0, 0, WINDOW_FORMAT_RGB_565);
#else
    (void)env;
    (void)surface;
#endif
}
