# Third-party notices

## PCSX ReARMed

- Project: https://github.com/libretro/pcsx_rearmed
- Pinned commit: `ff81ed17a15241d2f3730cdd7585b38e172532ca`
- License: GPL-2.0
- Android build: upstream `jni/Android.mk` and `jni/Application.mk` at the pinned commit (the makefile defines `LOCAL_MODULE := retro`, producing `libretro.so`).
- Build files: [Android.mk at pinned commit](https://github.com/libretro/pcsx_rearmed/blob/ff81ed17a15241d2f3730cdd7585b38e172532ca/jni/Android.mk) and [Application.mk at pinned commit](https://github.com/libretro/pcsx_rearmed/blob/ff81ed17a15241d2f3730cdd7585b38e172532ca/jni/Application.mk)
- License file: upstream `COPYING`; the build script copies it into `app/src/main/assets/licenses/PCSX-ReARMed-COPYING`.
- Local build patch: `patches/pcsx-rearmed-16kb-page-alignment.patch` adds the NDK r27 `common-page-size=16384` linker flag; this modification is included in the matching core source archive.
- Corresponding source: the local build script emits `PSX-ReARMed-<commit>-source.tar.gz` by default; GitHub Actions names the uploaded matching source archive `PSX-ReARMed-source.tar.gz`.

PCSX ReARMed supports BIOS HLE, but HLE compatibility is not guaranteed for every game. No Sony BIOS/firmware is included.

## Libretro API declarations

`app/src/main/cpp/include/libretro_api_subset.h` contains the small ABI declaration subset used by the native frontend. It is based on the public Libretro API and preserves the MIT license notice and copyright attribution for the API declarations. The canonical API header is maintained at https://github.com/libretro/libretro-common/blob/master/include/libretro.h. Before expanding API coverage, compare the subset against the canonical header and preserve the same notice.

## Android NDK and CMake

Android NDK and CMake are build tools, not bundled third-party application assets.

No game image, BIOS, Sony firmware, Sony trademark artwork, or cover art is bundled.
