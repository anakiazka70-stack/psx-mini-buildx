# PSX Mini currently has no custom ProGuard rules.
