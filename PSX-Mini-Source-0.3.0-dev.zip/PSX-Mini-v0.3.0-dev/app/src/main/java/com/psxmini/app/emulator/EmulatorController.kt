package com.psxmini.app.emulator

import java.io.File

/** Performs a cheap package check; the core is actually initialized only when a game is launched. */
class EmulatorController(private val nativeLibraryDir: File) {
    fun probePackagedCore(): String {
        val coreFile = File(nativeLibraryDir, CORE_LIBRARY_NAME)
        return if (coreFile.isFile) {
            "CORE_FILE_FOUND: PCSX ReARMed binary is packaged. Runtime initialization will be checked when a game starts."
        } else {
            "CORE_NOT_FOUND: PCSX ReARMed is not packaged for this device ABI."
        }
    }

    fun gameplayStatus(): String =
        "The core is initialized by the player when you press Play. Actual PCSX ReARMed gameplay still needs device verification."

    companion object {
        const val CORE_LIBRARY_NAME = "libpcsx_rearmed_libretro.so"
    }
}
